@echo off
chcp 65001 > nul
title Cyber Infrastructure Protection Sentinel Server
echo Starting Smart City Cyber Infrastructure Protection Server...
python server.py
pause
