# 🛡️ Smart City Critical Infrastructure Protection & Cyber-Resilience Sentinel

An open-source, zero-trust cyber-physical security module engineered to defend smart city digital infrastructure—including Power Grids, Water Treatment Plants, Transportation Networks, and Emergency CAD Public Services—against simultaneous multi-vector cyber attacks.

---

## 🌟 Key Features & Capabilities

1. **⚡ Smart Power Grid SCADA Protection**: Real-time voltage/frequency anomaly detection and self-healing air-gapped microgrid hardware isolation.
2. **💧 Water Treatment PLC Security**: Cryptographic SHA-256 state snapshot verification and rapid firmware rollback to instantly purge ransomware injections.
3. **🚆 Intelligent Transit System (ITS) Defense**: MitM spoofing detection and automated TLS 1.3 mTLS tunnel re-keying across Metro signaling relays.
4. **🚑 Emergency CAD Public Service Resilience**: Volumetric DDoS flood mitigation and automatic satellite mesh failover for uninterrupted emergency dispatch.
5. **🖥️ Live Zero-Trust Audit Sentinel**: Encrypted telemetry stream logging and real-time payload divergence tracking.

---

## 📁 Repository Structure

```text
📁 cyber-infrastructure-protection-module/
 ├── 📄 index.html        # Standalone Web Dashboard & Control HUD
 ├── 📄 server.py          # UTF-8 Python HTTP Server (Port 8090)
 ├── 📄 start.bat          # 1-Click Windows Launcher Script
 ├── 📄 README.md          # Comprehensive GitHub Documentation
 ├── 📁 css/
 │    └── 📄 style.css    # Glassmorphism & Cyber Pulse Stylesheets
 └── 📁 js/
      └── 📄 cyber-resilience.js # Decoupled Cyber Resilience Sentinel Engine
```

---

## 🚀 Quick Start Instructions

1. **Clone or Copy this Repository**:
   ```bash
   git clone https://github.com/your-username/cyber-infrastructure-protection.git
   cd cyber-infrastructure-protection
   ```

2. **Launch the Server**:
   - On Windows: Double click `start.bat` or run `python server.py`
   - On Linux/macOS: Run `python3 server.py`

3. **Open in Browser**:
   Navigate to [http://localhost:8090](http://localhost:8090)

---

## 🛡️ License & Attributions
Engineered for smart city safety, public space protection, and critical infrastructure resilience. Open-source under MIT License.
