﻿/**
 * RAKSHA-SETU 360 - Live Crisis Interactive Scenario Simulation Engine
 */

class SimulationEngine {
  constructor() {
    this.currentScenario = 'deekshabhoomi';
    this.currentStep = 0;
    this.isPlaying = false;
    this.playInterval = null;
    this.speedMs = 4000; // 4s per step

    this.scenarios = {
      deekshabhoomi: {
        title: "Deekshabhoomi Mass Gathering: Missing Child & Exit Bottleneck Crisis",
        subtitle: "Dhammachakra Pravartan Din (6.5 Lakh Gathering) • 5:40 PM Timeline",
        steps: [
          {
            time: "5:40 PM",
            badge: "INCIDENT OCCURRED",
            badgeColor: "rose",
            title: "Child Separation in Dense Stupa Crowd",
            description: "6-year-old Aaradhya Meshram separates from her parents (visiting from Chandrapur) near the Sacred Stupa perimeter amidst dense pedestrian movement.",
            traditionalGap: "Traditional Failure: 25-minute delay reaching a single desk; paper register logging with zero connection to other 7 desks or volunteers.",
            solutionFix: "RAKSHA-SETU Fix: Instant mobile desk intake or citizen kiosk logs photo, clothing tags, and biometric descriptors in 45 seconds.",
            action: (app) => {
              window.tacticalMap.map.setView([21.1278, 79.0667], 17);
              window.soundEngine.playEmergencyAlarm();
              app.showToast("🚨 Alert: Missing Child Reported near Stupa (Aaradhya Meshram, Age 6)", "warning");
            }
          },
          {
            time: "5:42 PM",
            badge: "RAPID DIGITAL INTAKE",
            badgeColor: "cyan",
            title: "Digital Multi-Desk Cloud Synchronization",
            description: "Helpdesk 2 (East Gate Plaza) captures photo & descriptors. The docket instantly syncs across all 8 Deekshabhoomi helpdesks and 450 registered volunteers.",
            traditionalGap: "Traditional Failure: Loudspeakers only cover the central VIP stage; isolated desks have no way to alert perimeter gates or volunteers.",
            solutionFix: "RAKSHA-SETU Fix: Privacy-preserved, watermarked volunteer push alert deployed to all beat officers and NSS units with zero social media leak risk.",
            action: (app) => {
              app.showToast("☁️ Multi-Desk Sync: Docket #MP-DKB-0042 synchronized across 8 desks & 450 field tablets", "info");
              window.soundEngine.playPAChime();
            }
          },
          {
            time: "5:45 PM",
            badge: "CROWD SURGE ALARM",
            badgeColor: "amber",
            title: "Real-Time Bottleneck Detected at Exits 2 & 4",
            description: "Surveillance AI & optical flow sensors detect critical crowd density surges at Exit 2 (89%) and Exit 4 (94%). Central Command initiates automated dynamic flow diversion.",
            traditionalGap: "Traditional Failure: Control room relies on scattered phone calls and congested walkie-talkies with no real-time GIS density visualization.",
            solutionFix: "RAKSHA-SETU Fix: Optical flow heatmap triggers dynamic LED exit signs and zoned loudspeaker rerouting towards Green Channel Exit 3 (32% capacity).",
            action: (app) => {
              window.tacticalMap.renderCrowdDensityZones();
              window.tacticalMap.drawCrowdDiversionFlow();
              window.soundEngine.broadcastAnnouncement(APP_DATA.audioAnnouncements.marathi.exit_diversion, 'mr', 'Exits 2 & 4 Perimeter');
              app.showToast("⚠️ Exit Bottleneck Alert: Automated crowd diversion initiated towards Green Channel Exit 3", "warning");
            }
          },
          {
            time: "5:48 PM",
            badge: "AI CCTV MATCH",
            badgeColor: "emerald",
            title: "Computer Vision Camera #09 Locks 94.2% Positive Match",
            description: "Perimeter Camera CAM-09 at Gate 3 Bajaj Nagar detects visual match based on pink floral frock, yellow hair clip, and facial geometry vector.",
            traditionalGap: "Traditional Failure: Unverified photos shared on social media cause false panic, spam sightings, and vigilantism.",
            solutionFix: "RAKSHA-SETU Fix: Neural edge vision matches target autonomously without exposing citizen faces to public social media.",
            action: (app) => {
              window.tacticalMap.highlightChildSighting([21.1255, 79.0669], "Aaradhya Meshram");
              window.soundEngine.playMatchSuccess();
              app.showToast("🎯 POSITIVE AI MATCH: Camera CAM-09 at Gate 3 locked 94.2% confidence!", "success");
            }
          },
          {
            time: "5:50 PM",
            badge: "VOLUNTEER INTERCEPT",
            badgeColor: "purple",
            title: "NSS Volunteer Unit 7 Safely Escorts Child",
            description: "Nearest responder (Rohan Somkuwar, NSS Unit 7) located 40 meters away receives direct push alert and escorts Aaradhya to the Child Care Sanctuary at Gate 3.",
            traditionalGap: "Traditional Failure: Scattered personnel unaware of child's appearance; child risks wandering onto busy main roads.",
            solutionFix: "RAKSHA-SETU Fix: Geofenced volunteer dispatch with verified digital credential badge ensures calm, trained assistance in under 90 seconds.",
            action: (app) => {
              app.showToast("🛡️ Volunteer Intercept: Child safely accompanied to Gate 3 Child Sanctuary", "info");
            }
          },
          {
            time: "5:55 PM",
            badge: "REUNITED SAFELY",
            badgeColor: "emerald",
            title: "Parent Handover via Secure OTP Verification",
            description: "Parents arrive at Gate 3 Helpdesk. Secure cryptographic OTP handshake verified by PSI Patil. Aaradhya safely reunited with her family from Chandrapur!",
            traditionalGap: "Traditional Failure: Hours of agonizing search, parent trauma, and chaotic stampede risks near exits.",
            solutionFix: "RAKSHA-SETU Fix: Total resolution time under 15 minutes with complete audit trail, exit crowd normalized, zero panic.",
            action: (app) => {
              window.soundEngine.broadcastAnnouncement(APP_DATA.audioAnnouncements.marathi.child_found, 'mr', 'Gate 3 Helpdesk');
              app.showToast("🎉 SUCCESSFUL REUNION: Aaradhya safely returned to parents! Incident resolved in 15 mins.", "success");
            }
          }
        ]
      },

      saferide: {
        title: "Daily Life Safety: Late-Night Shared Auto Route Deviation",
        subtitle: "Sitabuldi to Dharampeth West • 10:14 PM Route Anomaly Detection",
        steps: [
          {
            time: "10:05 PM",
            badge: "TRIP STARTED",
            badgeColor: "cyan",
            title: "Citizen Boards Shared Auto at Sitabuldi",
            description: "Pooja (24) starts SafeRide Guardian on her phone. Intended route to Dharampeth is mapped and shared with her 3 trusted emergency contacts.",
            traditionalGap: "Traditional: Commuter has no active tracking, unable to speak loudly if route changes without alerting the driver.",
            solutionFix: "RAKSHA-SETU: Real-time background GPS geofencing monitoring route corridor with 150m tolerance bounds.",
            action: (app) => {
              app.showToast("🚕 SafeRide Active: Monitoring route corridor from Sitabuldi", "info");
            }
          },
          {
            time: "10:12 PM",
            badge: "DEVIATION DETECTED",
            badgeColor: "amber",
            title: "Vehicle Drifts 480m Off-Route into Dark By-lane",
            description: "Auto turns away from well-lit main road into an isolated forest bypass. The app detects a 480m anomaly and sends a silent vibration prompt.",
            traditionalGap: "Traditional: Passenger panics; difficult to explain remote coordinates to emergency police number over call.",
            solutionFix: "RAKSHA-SETU: Auto-Countdown triggered (15s to dismiss). Stealth Triple-Tap or silent countdown triggers high-priority SOS.",
            action: (app) => {
              window.soundEngine.playEmergencyAlarm();
              app.showToast("⚠️ Route Drift Anomaly: Vehicle diverted 480m off designated path!", "warning");
            }
          },
          {
            time: "10:14 PM",
            badge: "STEALTH SOS ACTIVE",
            badgeColor: "rose",
            title: "Police PCR Intercept & Fake Call Shield",
            description: "High-priority alert dispatched to Police Control Room. PCR Van 14 dispatched to intercept coordinates. App generates a realistic fake call ('Inspector Dad Calling') to deter driver.",
            traditionalGap: "Traditional: Delayed response after severe incident has already escalated.",
            solutionFix: "RAKSHA-SETU: PCR Van intercepts within 4 minutes at next junction. Citizen safe.",
            action: (app) => {
              app.showToast("🚔 Police PCR Intercept Dispatched to Seminary Hills Bypass!", "success");
            }
          }
        ]
      },

      chainsnatch: {
        title: "Citizen Whistleblower: Anonymous Rapid Crime Reporting",
        subtitle: "Shraddhanand Anathalaya Junction • 9:35 PM Instant Docketing",
        steps: [
          {
            time: "9:35 PM",
            badge: "CRIME WITNESSED",
            badgeColor: "rose",
            title: "Two Bike Riders Snatch Gold Chain",
            description: "A bystander witnesses a chain-snatching incident. Instead of walking away due to fear of police harassment or court visits, they open RAKSHA-SETU.",
            traditionalGap: "Traditional: 80% of citizens avoid reporting due to identity exposure, FIR hassles, and witness interrogation fears.",
            solutionFix: "RAKSHA-SETU: 100% Anonymous Whistleblower Shield. Cryptographic token generated without asking for personal identification.",
            action: (app) => {
              app.showToast("📸 Citizen Witness capturing 5-second rapid crime snapshot...", "info");
            }
          },
          {
            time: "9:36 PM",
            badge: "DOCKET GENERATED",
            badgeColor: "cyan",
            title: "Instant Geo-Tagged Docket & CCTV Auto-Bookmark",
            description: "Docket #CR-8811 created with exact GPS coordinates and suspect description (Black Pulsar, Red Helmet). The system automatically bookmarks the corresponding 60-second clip on City Camera CAM-104.",
            traditionalGap: "Traditional: CCTV footage overwritten or retrieved days later after crucial evidence is lost.",
            solutionFix: "RAKSHA-SETU: Zero-touch CCTV bookmarking within 30 seconds of incident report.",
            action: (app) => {
              window.soundEngine.playMatchSuccess();
              app.showToast("💾 Docket #CR-8811 generated & CAM-104 footage locked securely!", "success");
            }
          }
        ]
      }
    };
  }

  loadScenario(key) {
    if (!this.scenarios[key]) return;
    this.currentScenario = key;
    this.currentStep = 0;
    this.stopAutoPlay();
  }

  getCurrentScenarioData() {
    return this.scenarios[this.currentScenario];
  }

  getCurrentStepData() {
    const scenario = this.getCurrentScenarioData();
    return scenario.steps[this.currentStep];
  }

  nextStep(app) {
    const scenario = this.getCurrentScenarioData();
    if (this.currentStep < scenario.steps.length - 1) {
      this.currentStep++;
      const step = scenario.steps[this.currentStep];
      if (step.action) step.action(app);
      return true;
    } else {
      this.stopAutoPlay();
      return false;
    }
  }

  prevStep(app) {
    if (this.currentStep > 0) {
      this.currentStep--;
      const step = this.getCurrentScenarioData().steps[this.currentStep];
      if (step.action) step.action(app);
      return true;
    }
    return false;
  }

  goToStep(index, app) {
    const scenario = this.getCurrentScenarioData();
    if (index >= 0 && index < scenario.steps.length) {
      this.currentStep = index;
      const step = scenario.steps[this.currentStep];
      if (step.action) step.action(app);
      return true;
    }
    return false;
  }

  startAutoPlay(app, onUpdateCallback) {
    this.isPlaying = true;
    this.playInterval = setInterval(() => {
      const hasNext = this.nextStep(app);
      if (onUpdateCallback) onUpdateCallback();
      if (!hasNext) {
        this.stopAutoPlay();
      }
    }, this.speedMs);
  }

  stopAutoPlay() {
    this.isPlaying = false;
    if (this.playInterval) {
      clearInterval(this.playInterval);
      this.playInterval = null;
    }
  }
}

window.simEngine = new SimulationEngine();
