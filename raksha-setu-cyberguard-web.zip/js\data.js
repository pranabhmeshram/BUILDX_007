﻿/**
 * RAKSHA-SETU 360 - Comprehensive Dataset & Telemetry Matrix
 */

const APP_DATA = {
  festival: {
    name: "Dhammachakra Pravartan Din - 68th Anniversary",
    location: "Deekshabhoomi, Nagpur, Maharashtra",
    totalFootfallEstimate: "6,50,000+",
    activeVolunteers: 450,
    activePolicePersonnel: 1200,
    cctvCount: 14,
    helpdesksCount: 8,
    medicalStationsCount: 6,
    emergencyExits: 4,
    waterATMs: 12,
    foodLangars: 8
  },

  geoCenter: [21.1278, 79.0667],

  // Landmarks & Key Infrastructure
  landmarks: [
    { id: "stupa", name: "Sacred Stupa & Bodhi Tree Plaza", type: "monument", coords: [21.1278, 79.0667], crowdLevel: 82, capacity: 50000 },
    { id: "main_stage", name: "Central Cultural Stage & VIP Dais", type: "stage", coords: [21.1288, 79.0665], crowdLevel: 91, capacity: 25000 },
    { id: "gate_1", name: "Gate 1 - North Entrance (VIP & Media)", type: "gate", coords: [21.1302, 79.0668], status: "normal", flowRate: 140, maxFlow: 300 },
    { id: "gate_2", name: "Gate 2 - East Entrance (Laxmi Nagar Road)", type: "gate", coords: [21.1280, 79.0695], status: "heavy", flowRate: 380, maxFlow: 400 },
    { id: "gate_3", name: "Gate 3 - South Gate (Bajaj Nagar)", type: "gate", coords: [21.1255, 79.0669], status: "normal", flowRate: 210, maxFlow: 350 },
    { id: "gate_4", name: "Gate 4 - West Gate (Shraddhanand Peth)", type: "gate", coords: [21.1275, 79.0638], status: "critical", flowRate: 460, maxFlow: 420 },
    { id: "exit_1", name: "Emergency Exit 1 (North-East Perimeter)", type: "exit", coords: [21.1295, 79.0685], crowdLevel: 45, status: "clear" },
    { id: "exit_2", name: "Emergency Exit 2 (East Perimeter Corridor)", type: "exit", coords: [21.1270, 79.0690], crowdLevel: 89, status: "bottleneck_alert" },
    { id: "exit_3", name: "Emergency Exit 3 (South Perimeter Meadow)", type: "exit", coords: [21.1258, 79.0652], crowdLevel: 32, status: "green_channel" },
    { id: "exit_4", name: "Emergency Exit 4 (South-West Funnel Gate)", type: "exit", coords: [21.1262, 79.0640], crowdLevel: 94, status: "bottleneck_alert" },
    { id: "control_room", name: "Unified Police & District ICCC Bunker", type: "hq", coords: [21.1290, 79.0650], staff: 24 },
    { id: "medical_1", name: "Disaster Response Medical Camp A", type: "medical", coords: [21.1270, 79.0655], beds: 30, ambulances: 4 },
    { id: "medical_2", name: "Red Cross First-Aid Station B", type: "medical", coords: [21.1282, 79.0680], beds: 15, ambulances: 2 }
  ],

  // Ground Pilgrim Facilities
  pilgrimFacilities: [
    { id: "W-01", name: "Clean RO Water ATM #1 (Stupa North)", type: "water", coords: [21.1285, 79.0660], status: "operational", queueTime: "1 min" },
    { id: "W-02", name: "RO Water ATM #2 (Food Stall Plaza)", type: "water", coords: [21.1272, 79.0678], status: "operational", queueTime: "3 mins" },
    { id: "W-03", name: "Cold Drinking Water Post #3 (Gate 3)", type: "water", coords: [21.1257, 79.0665], status: "operational", queueTime: "2 mins" },
    { id: "L-01", name: "Community Langar & Mahaprasad Hall A", type: "food", coords: [21.1295, 79.0672], capacity: "3,000/hr", status: "open" },
    { id: "L-02", name: "Community Food Distribution Tent B", type: "food", coords: [21.1265, 79.0685], capacity: "2,000/hr", status: "open" },
    { id: "M-01", name: "Emergency Medical Mobile ICU (Bajaj Nagar)", type: "medical", coords: [21.1252, 79.0672], doctors: 4, ambulances: 3 },
    { id: "T-01", name: "Sanitary Restroom Complex North", type: "washroom", coords: [21.1298, 79.0658], status: "clean", queue: "Low" },
    { id: "T-02", name: "Sanitary Restroom Complex South-East", type: "washroom", coords: [21.1265, 79.0692], status: "clean", queue: "Moderate" }
  ],

  // 8 Synchronized Police Helpdesks
  helpDesks: [
    { id: "HD-01", name: "Desk 1 (North Gate Entrance)", officer: "PSI S. Kulkarni", phone: "+91 98230 00101", status: "online", activeCases: 2 },
    { id: "HD-02", name: "Desk 2 (East Gate Plaza)", officer: "ASI M. Sheikh", phone: "+91 98230 00102", status: "online", activeCases: 4 },
    { id: "HD-03", name: "Desk 3 (South-West Gate / Exit 4)", officer: "Inspector V. Patil", phone: "+91 98230 00103", status: "online", activeCases: 3 },
    { id: "HD-04", name: "Desk 4 (Stupa Inner Parikrama)", officer: "Constable A. Wankhede", phone: "+91 98230 00104", status: "online", activeCases: 1 },
    { id: "HD-05", name: "Desk 5 (Food Stalls & Book Expo)", officer: "PSI R. Meshram", phone: "+91 98230 00105", status: "online", activeCases: 0 },
    { id: "HD-06", name: "Desk 6 (Medical & Transit Junction)", officer: "ASI T. Gaikwad", phone: "+91 98230 00106", status: "online", activeCases: 1 },
    { id: "HD-07", name: "Desk 7 (Shraddhanand Peth Parking)", officer: "Constable P. Rathod", phone: "+91 98230 00107", status: "online", activeCases: 0 },
    { id: "HD-08", name: "Desk 8 (Laxmi Nagar Bus Terminal)", officer: "PSI G. Ingle", phone: "+91 98230 00108", status: "online", activeCases: 2 }
  ],

  // Full 14-Channel CCTV Matrix
  cctvStreams: [
    { id: "CAM-01", name: "Stupa North Parikrama Cam", zone: "Zone 1 (Stupa)", coords: [21.1280, 79.0667], density: "High (86%)", densityVal: 86, status: "active", aiFlags: ["Density Surge", "Child Watch Active"], streamImg: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-02", name: "Stupa South Bodhi Tree View", zone: "Zone 1 (Stupa)", coords: [21.1275, 79.0665], density: "Normal (64%)", densityVal: 64, status: "active", aiFlags: ["Smooth Flow"], streamImg: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-03", name: "Gate 1 North VIP Ingress", zone: "Zone 1 (North Gate)", coords: [21.1302, 79.0668], density: "Low (38%)", densityVal: 38, status: "active", aiFlags: ["VIP Clear"], streamImg: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-04", name: "Exit 2 Funnel Thermal Surge", zone: "Zone 3 (East Exit)", coords: [21.1270, 79.0690], density: "Critical (89%)", densityVal: 89, status: "warning", aiFlags: ["Bottleneck Risk", "Flow Stoppage"], streamImg: "https://images.unsplash.com/photo-1477959858617-67f30bc54b1f?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-05", name: "East Laxmi Nagar Approach", zone: "Zone 3 (East Road)", coords: [21.1280, 79.0698], density: "Heavy (78%)", densityVal: 78, status: "active", aiFlags: ["Traffic Diverted"], streamImg: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-06", name: "Exit 1 North-East Green Lane", zone: "Zone 2 (North-East)", coords: [21.1295, 79.0685], density: "Low (45%)", densityVal: 45, status: "active", aiFlags: ["Flow Smooth"], streamImg: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-07", name: "Exit 4 South-West Optical Flow", zone: "Zone 4 (South-West)", coords: [21.1262, 79.0640], density: "Severe (94%)", densityVal: 94, status: "danger", aiFlags: ["High Stampede Hazard", "Gate Jammed"], streamImg: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-08", name: "Shraddhanand Peth Parking", zone: "Zone 4 (West)", coords: [21.1272, 79.0635], density: "Normal (52%)", densityVal: 52, status: "active", aiFlags: ["Parking Normal"], streamImg: "https://images.unsplash.com/photo-1477959858617-67f30bc54b1f?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-09", name: "Gate 3 Bajaj Nagar Perimeter AI", zone: "Zone 5 (South Gate)", coords: [21.1255, 79.0669], density: "Moderate (54%)", densityVal: 54, status: "match_alert", aiFlags: ["AI FACIAL MATCH 94.2%", "Target Located"], streamImg: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-10", name: "Exit 3 South Meadow Green Corridor", zone: "Zone 5 (South Meadow)", coords: [21.1258, 79.0652], density: "Clear (32%)", densityVal: 32, status: "active", aiFlags: ["Green Channel Active"], streamImg: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-11", name: "Central Book Exhibition Way", zone: "Zone 2 (Central)", coords: [21.1272, 79.0675], density: "Normal (61%)", densityVal: 61, status: "active", aiFlags: ["Normal Flow"], streamImg: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-12", name: "Mahaprasad Langar Hall A", zone: "Zone 2 (Langar)", coords: [21.1295, 79.0672], density: "Busy (74%)", densityVal: 74, status: "active", aiFlags: ["Orderly Queue"], streamImg: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-13", name: "Medical Camp A Perimeter", zone: "Zone 4 (Medical)", coords: [21.1270, 79.0655], density: "Controlled (35%)", densityVal: 35, status: "active", aiFlags: ["Ambulance Priority Open"], streamImg: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=400&auto=format&fit=crop&q=80" },
    { id: "CAM-14", name: "VIP Stage Backstage Access", zone: "Zone 1 (VIP)", coords: [21.1292, 79.0660], density: "Controlled (28%)", densityVal: 28, status: "active", aiFlags: ["Perimeter Secure"], streamImg: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&auto=format&fit=crop&q=80" }
  ],

  // Missing Person Cases
  missingCases: [
    {
      id: "MP-DKB-2026-0042",
      name: "Aaradhya Meshram",
      age: 6,
      gender: "Female",
      hometown: "Chandrapur, Maharashtra",
      reportedTime: "5:40 PM",
      timeElapsedMins: 15,
      reportedAtDesk: "HD-02 (East Gate Plaza)",
      parentsName: "Sunil & Vandana Meshram",
      contact: "+91 94231 88921",
      appearance: {
        dress: "Pink Frock with Floral Print",
        accessories: "Yellow Hair Clip, Red Silk Wristband",
        height: "3 ft 6 in",
        complexion: "Fair",
        identifyingMark: "Small mole on left cheek"
      },
      status: "AI_MATCH_LOCATED",
      matchDetails: {
        camera: "CAM-09 (Gate 3 Bajaj Nagar Perimeter)",
        confidence: "94.2%",
        timestamp: "5:48:12 PM",
        nearestVolunteer: "NSS Unit 7 (Rohan Somkuwar)",
        safeSanctuary: "Child Care Booth at Gate 3"
      },
      avatar: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=200&auto=format&fit=crop&q=80",
      broadcastScope: "Protected Volunteer Channel (Watermarked Cryptographic Push)"
    },
    {
      id: "MP-DKB-2026-0043",
      name: "Rameshwar Rao",
      age: 72,
      gender: "Male",
      hometown: "Wardha",
      reportedTime: "4:15 PM",
      timeElapsedMins: 90,
      reportedAtDesk: "HD-05 (Food Stalls)",
      parentsName: "Son: Dr. Amit Rao",
      contact: "+91 98902 44312",
      appearance: {
        dress: "White Kurta Pyjama, Blue Nehru Jacket",
        accessories: "Black spectacles, Walking stick with QR badge",
        height: "5 ft 8 in",
        complexion: "Wheatish",
        identifyingMark: "Wears medical silver alert wristband (Dementia)"
      },
      status: "SEARCHING",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80",
      broadcastScope: "City Silver Alert & Auto-Rickshaw Union Channel"
    }
  ],

  // PTT Digital Radio Channels
  radioChannels: [
    { id: "CH-01", name: "Channel 1: Medical & Ambulance Priority", freq: "154.250 MHz", activeUsers: 14, lastLog: "Ambulance 4 standing by at Bajaj Nagar Road gate" },
    { id: "CH-02", name: "Channel 2: Crowd Flow & Exit Gate Regulators", freq: "155.400 MHz", activeUsers: 28, lastLog: "Exit 4 bottleneck diversion initiated to Exit 3 green lane" },
    { id: "CH-03", name: "Channel 3: Lost & Found / NSS Volunteer Net", freq: "156.800 MHz", activeUsers: 42, lastLog: "NSS Unit 7 confirmed child Aaradhya Meshram in safe sanctuary" },
    { id: "CH-04", name: "Channel 4: City Police PCR & Traffic Outer Ring", freq: "158.125 MHz", activeUsers: 20, lastLog: "Laxmi Nagar traffic diversions running smooth" },
    { id: "CH-05", name: "Channel 5: VIP Security & Stage Perimeter", freq: "160.050 MHz", activeUsers: 16, lastLog: "VIP Dais sanitization cleared" }
  ],

  // Volunteer Units
  volunteerUnits: [
    { id: "VOL-01", leader: "NSS Unit 1 - Rahul B.", zone: "Gate 1 North", count: 18, status: "patrolling", coords: [21.1298, 79.0667] },
    { id: "VOL-04", leader: "Samata Sainik Dal Unit 4", zone: "Exit 2 Corridor", count: 25, status: "diverting_crowd", coords: [21.1272, 79.0688] },
    { id: "VOL-07", leader: "NSS Unit 7 - Rohan S.", zone: "Gate 3 South", count: 14, status: "child_intercept_assigned", coords: [21.1256, 79.0671] },
    { id: "VOL-11", leader: "Civil Defence Unit 11", zone: "Exit 4 West Funnel", count: 30, status: "bottleneck_relief", coords: [21.1264, 79.0642] }
  ],

  // Urban Incidents
  urbanIncidents: [
    {
      id: "INC-2026-9810",
      type: "SAFE_RIDE_DEVIATION",
      title: "Shared Auto-Rickshaw Route Deviation Anomaly",
      victim: "Pooja Sharma (Software Engineer, 24)",
      vehicleNumber: "MH-31-EQ-4412 (Yellow-Black Auto)",
      pickup: "Sitabuldi Metro Station",
      intendedDestination: "Dharampeth West",
      driftLocation: "Isolated Bypass near Seminary Hills Forest",
      driftDistance: "480 meters off-route",
      status: "POLICE_INTERCEPT_DISPATCHED",
      sosTriggeredBy: "AI Auto-Drift Detector & Stealth Triple-Tap",
      time: "10:14 PM",
      assignedPCR: "PCR Van 14 (SI D. Joshi)"
    },
    {
      id: "INC-2026-9811",
      type: "ANONYMOUS_CRIME_REPORT",
      title: "Gold Chain Snatching by Two Bike Riders",
      reportedBy: "Anonymous Citizen Witness (Whistleblower Shield #W-902)",
      location: "Near Shraddhanand Anathalaya Road Junction",
      suspectDetails: "2 Males on Black Pulsar (No Plate), Red Helmet, Black Jacket",
      evidence: "1 Photo + 10s audio recorded anonymously",
      status: "CCTV_BOOKMARKED_PATROL_ALERTED",
      time: "09:35 PM",
      cctvSynced: "CAM-CITY-104 (Shraddhanand Junction 360)"
    }
  ],

  // Zoned Announcements
  audioAnnouncements: {
    marathi: {
      child_search: "लक्ष द्या! ६ वर्षांची मुलगी आराध्या मेश्राम (गुलाबी फ्रॉक, पिवळा क्लिप) आपल्या पालकांपासून वेगळी झाली आहे. कोणालाही आढळल्यास जवळच्या गेट ३ किंवा सुरक्षा डेस्कशी संपर्क साधावा.",
      exit_diversion: "कृपया लक्ष द्या! गेट २ आणि गेट ४ वरील गर्दी कमी करण्यासाठी, सर्व भाविकांनी कृपया गेट १ आणि गेट ३ चा वापर करावा. दोन्ही मार्ग पूर्णपणे मोकळे आहेत.",
      child_found: "आनंदाची बातमी! हरवलेली मुलगी आराध्या मेश्राम गेट ३ वरील पोलीस मदत केंद्रात सुरक्षित पोहोचली आहे. पालकांनी त्वरित तिथे संपर्क साधावा."
    },
    hindi: {
      child_search: "कृपया ध्यान दें! ६ वर्ष की बालिका आराध्या मेश्राम (गुलाबी फ्रॉक, पीली हेयरक्लिप) अपने परिवार से अलग हो गई हैं। मिलते ही निकटतम गेट ३ सहायता केंद्र पर सूचित करें।",
      exit_diversion: "यात्रियों से अनुरोध है कि गेट २ और ४ पर भीड़ के कारण, कृपया सुगम निकास हेतु गेट १ और गेट ३ का उपयोग करें।",
      child_found: "सूचना: बालिका आराध्या मेश्राम गेट ३ बाल सुरक्षा केंद्र पर सुरक्षित मिल गई हैं। परिजन कृपया गेट ३ पहुंचें।"
    },
    english: {
      child_search: "Attention please: 6-year-old Aaradhya Meshram in a pink frock has been reported missing. If sighted, please notify the nearest Helpdesk or Gate 3 Police Post.",
      exit_diversion: "Crowd Advisory: Due to heavy flow at Exits 2 & 4, visitors are requested to use Exits 1 & 3 for a smooth and safe exit.",
      child_found: "Good news: Missing child Aaradhya Meshram has been safely escorted to the Gate 3 Helpdesk. Parents may proceed for reunion."
    }
  }
};

window.APP_DATA = APP_DATA;
