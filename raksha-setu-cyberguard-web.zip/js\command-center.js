﻿/**
 * RAKSHA-SETU 360 - Integrated Command & Control Center (ICCC) Dashboard Logic
 */

class CommandCenterModule {
  constructor() {
    this.activeTab = 'map';
    this.selectedZone = 'all';
    this.crowdAlertActive = true;
    this.selectedCCTV = null;
    this.radioChannel = "CH-01 (Medical & Disaster)";
  }

  // Calculate Aggregated Ground Telemetry
  getSummaryStats() {
    const totalCCTV = APP_DATA.cctvStreams.length;
    const activeAlerts = APP_DATA.cctvStreams.filter(c => c.status !== 'active').length + 2;
    const missingCount = APP_DATA.missingCases.filter(c => c.status !== 'REUNITED').length;
    const avgDensity = 76; // 76% aggregate crowd density

    return {
      totalCCTV,
      activeAlerts,
      missingCount,
      avgDensity,
      activeVolunteers: APP_DATA.volunteerUnits.reduce((acc, v) => acc + v.count, 0)
    };
  }

  // Trigger Localized Zoned Audio PA Broadcast
  triggerBroadcast(zoneKey, text, lang = 'mr') {
    const zoneLabels = {
      all: "All Deekshabhoomi Zones",
      stupa: "Zone 1 (Stupa & Central Dais)",
      food: "Zone 2 (Food Stalls & Book Expo)",
      exit2: "Zone 3 (East Gate & Exit 2)",
      exit4: "Zone 4 (South-West & Exit 4)",
      gate3: "Zone 5 (Gate 3 Bajaj Nagar)"
    };

    const zoneName = zoneLabels[zoneKey] || "Designated Zone";
    window.soundEngine.broadcastAnnouncement(text, lang, zoneName);
  }

  // Dynamic Crowd Flow Diversion Activator
  activateDynamicRerouting() {
    window.tacticalMap.renderCrowdDensityZones();
    window.tacticalMap.drawCrowdDiversionFlow();
    window.soundEngine.playEmergencyAlarm();
    this.triggerBroadcast('exit2', APP_DATA.audioAnnouncements.marathi.exit_diversion, 'mr');
    return {
      status: "ACTIVE",
      timestamp: new Date().toLocaleTimeString(),
      divertedGates: ["Exit 2 (East)", "Exit 4 (South-West)"],
      openedChannels: ["Exit 1 (North)", "Exit 3 (South Meadow - Green Corridor)"]
    };
  }
}

window.commandCenter = new CommandCenterModule();
