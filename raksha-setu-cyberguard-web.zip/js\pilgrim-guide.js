﻿/**
 * RAKSHA-SETU 360 - Deekshabhoomi Pilgrim Assistance & Ground Facility Finder
 */

class PilgrimGuideModule {
  constructor() {
    this.selectedFilter = 'all';
  }

  getFilteredFacilities(type = 'all') {
    if (type === 'all') return APP_DATA.pilgrimFacilities;
    return APP_DATA.pilgrimFacilities.filter(f => f.type === type);
  }

  renderFacilityGrid(containerId = 'pilgrim-facility-grid') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const facilities = this.getFilteredFacilities(this.selectedFilter);
    const typeIcons = {
      water: '💧',
      food: '🍲',
      medical: '🏥',
      washroom: '🚻'
    };

    container.innerHTML = facilities.map(f => `
      <div class="glass-panel p-3.5 rounded-xl border border-slate-800 hover:border-cyan-500/40 transition space-y-1.5 cursor-pointer" onclick="window.tacticalMap.map.setView([${f.coords[0]}, ${f.coords[1]}], 18); window.app.showToast('📍 Navigating to ${f.name}', 'info');">
        <div class="flex items-center justify-between">
          <span class="text-sm font-bold text-white flex items-center gap-1.5">
            <span>${typeIcons[f.type] || '📍'}</span>
            <span>${f.name}</span>
          </span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono-code font-bold">
            ${f.status ? f.status.toUpperCase() : 'OPEN'}
          </span>
        </div>
        <p class="text-xs text-slate-400">
          ${f.queueTime ? `Wait Time: <span class="text-cyan-300 font-mono-code">${f.queueTime}</span>` : ''}
          ${f.capacity ? `Capacity: <span class="text-slate-200 font-mono-code">${f.capacity}</span>` : ''}
          ${f.doctors ? `Staff: <span class="text-emerald-300">${f.doctors} Doctors on duty</span>` : ''}
          ${f.queue ? `Queue: <span class="text-slate-300">${f.queue}</span>` : ''}
        </p>
      </div>
    `).join('');
  }
}

window.pilgrimGuide = new PilgrimGuideModule();
