﻿/**
 * RAKSHA-SETU 360 - Anonymous Crime Witness Reporting & Silver Alert Hub
 */

class IncidentReporterModule {
  constructor() {
    this.reports = [...APP_DATA.urbanIncidents];
  }

  submitAnonymousReport(formData) {
    const docketId = "CR-" + Math.floor(10000 + Math.random() * 90000);
    const token = "SHIELD-" + Math.random().toString(36).substring(2, 8).toUpperCase();
    
    const newReport = {
      id: docketId,
      shieldToken: token,
      type: formData.category || "WITNESS_CRIME_REPORT",
      title: formData.title || "Public Incident Report",
      location: formData.location || "Deekshabhoomi Vicinity",
      suspectDetails: formData.description || "Suspect fleeing on motorcycle",
      evidence: formData.hasPhoto ? "1 Photo Attached (EXIF Scrubbed)" : "Text Brief",
      status: "CCTV_BOOKMARKED_PATROL_ALERTED",
      time: new Date().toLocaleTimeString(),
      cctvSynced: "CAM-CITY-AUTO-LOCKED"
    };

    this.reports.unshift(newReport);
    window.soundEngine.playMatchSuccess();
    return newReport;
  }

  submitSilverAlert(seniorData) {
    const silverId = "SLV-" + Math.floor(1000 + Math.random() * 9000);
    const newSilverCase = {
      id: silverId,
      name: seniorData.name || "Senior Citizen",
      age: seniorData.age || 70,
      medicalNotes: seniorData.medicalNotes || "Mild Alzheimer's / Memory Loss",
      lastSeenLocation: seniorData.lastSeen || "Near Deekshabhoomi North Gate",
      reportedTime: new Date().toLocaleTimeString(),
      contact: seniorData.contact || "+91 98900 12345",
      qrBadgeNumber: "QR-MED-" + Math.random().toString(36).substring(2, 7).toUpperCase(),
      status: "SEARCHING_BROADCAST_ACTIVE"
    };

    APP_DATA.missingCases.push({
      id: silverId,
      name: newSilverCase.name,
      age: newSilverCase.age,
      gender: "Male",
      hometown: "Nagpur",
      reportedTime: newSilverCase.reportedTime,
      timeElapsedMins: 5,
      reportedAtDesk: "HD-01 (Citizen Mobile App)",
      parentsName: "Family: " + seniorData.contact,
      contact: seniorData.contact,
      appearance: {
        dress: seniorData.dress || "Kurta Pyjama",
        accessories: "Walking stick, Silver Alert QR tag",
        height: "5 ft 7 in",
        complexion: "Fair",
        identifyingMark: "Memory impairment"
      },
      status: "SEARCHING",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80",
      broadcastScope: "City Silver Alert & Auto-Rickshaw Union Channel"
    });

    window.soundEngine.playPAChime();
    return newSilverCase;
  }
}

window.incidentReporter = new IncidentReporterModule();
