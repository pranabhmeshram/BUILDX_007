﻿/**
 * RAKSHA-SETU 360 - Anti-Stampede Dynamic Crowd Automation Center
 */

class AntiStampedeModule {
  constructor() {
    this.gateRates = {
      gate1: 140, // persons/min
      gate2: 380,
      gate3: 210,
      gate4: 460, // critical
      exit1: 120,
      exit2: 90,  // jammed bottleneck
      exit3: 260, // green flow
      exit4: 80   // jammed bottleneck
    };
    this.diversionActive = false;
    this.hazardLevel = "ELEVATED_LEVEL_2";
  }

  setGateFlow(gateKey, rate) {
    this.gateRates[gateKey] = parseInt(rate);
    this.calculateHazardIndex();
  }

  calculateHazardIndex() {
    // Hazard based on Exit 2 and Exit 4 bottlenecks compared to influx at Gate 2 and Gate 4
    const totalInflow = this.gateRates.gate1 + this.gateRates.gate2 + this.gateRates.gate3 + this.gateRates.gate4;
    const totalOutflow = this.gateRates.exit1 + this.gateRates.exit2 + this.gateRates.exit3 + this.gateRates.exit4;
    const bottleneckRatio = (totalInflow / Math.max(1, totalOutflow)).toFixed(2);

    let hazard = "NORMAL_LEVEL_1";
    let score = Math.min(99, Math.round((bottleneckRatio / 2.5) * 85));

    if (this.gateRates.gate4 > 400 || this.gateRates.exit4 < 100 || score > 80) {
      hazard = "CRITICAL_LEVEL_3";
    } else if (score > 60) {
      hazard = "ELEVATED_LEVEL_2";
    }

    this.hazardLevel = hazard;
    return {
      inflowTotal: totalInflow,
      outflowTotal: totalOutflow,
      bottleneckRatio: bottleneckRatio,
      hazardLevel: hazard,
      hazardScore: score
    };
  }

  triggerAutomaticRerouting() {
    this.diversionActive = true;
    // Lower inflow at jammed gates and redirect to green channels
    this.gateRates.exit3 = 450; // Maximize green channel throughput
    this.gateRates.exit1 = 320;
    this.calculateHazardIndex();

    window.tacticalMap.renderCrowdDensityZones();
    window.tacticalMap.drawCrowdDiversionFlow();
    window.soundEngine.playEmergencyAlarm();
    window.soundEngine.broadcastAnnouncement(APP_DATA.audioAnnouncements.marathi.exit_diversion, 'mr', 'Exits 2 & 4 Perimeter');

    return {
      status: "DIVERSION_APPLIED",
      greenChannelsOpened: ["Exit 3 (South Meadow)", "Exit 1 (North-East)"],
      ledSignageUpdated: "Divert to Exits 1 & 3",
      timestamp: new Date().toLocaleTimeString()
    };
  }

  resetFlows() {
    this.diversionActive = false;
    this.gateRates = {
      gate1: 140,
      gate2: 380,
      gate3: 210,
      gate4: 460,
      exit1: 120,
      exit2: 90,
      exit3: 260,
      exit4: 80
    };
    this.calculateHazardIndex();
  }
}

window.antiStampede = new AntiStampedeModule();
