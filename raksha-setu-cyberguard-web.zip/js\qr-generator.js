﻿/**
 * RAKSHA-SETU 360 - Smart Safety Emergency QR ID Card Generator
 */

class SmartQRGeneratorModule {
  constructor() {
    this.currentCard = {
      type: "CHILD_SAFETY",
      name: "Aaradhya Meshram",
      age: 6,
      bloodGroup: "O+ Positive",
      guardian: "Sunil Meshram (Father)",
      contact: "+91 94231 88921",
      emergencyContact2: "+91 98220 11223",
      medicalNote: "Allergic to Penicillin • Deekshabhoomi Visitor",
      badgeId: "QR-SAFE-4482"
    };
  }

  generateCard(cardData) {
    this.currentCard = { ...this.currentCard, ...cardData };
    this.currentCard.badgeId = "QR-SAFE-" + Math.floor(1000 + Math.random() * 9000);
    window.soundEngine.playMatchSuccess();
    return this.currentCard;
  }

  renderCardPreview(containerId = 'qr-card-preview-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const c = this.currentCard;
    const isChild = c.type === 'CHILD_SAFETY';

    container.innerHTML = `
      <div class="emergency-qr-card space-y-3">
        <div class="flex items-center justify-between border-b border-cyan-500/30 pb-2">
          <div class="flex items-center gap-2">
            <span class="text-xl">${isChild ? '👧' : '👴'}</span>
            <div>
              <h4 class="text-xs font-black tracking-wider text-cyan-300 uppercase">${isChild ? 'SMART CHILD SAFETY PASS' : 'SILVER ALERT EMERGENCY PASS'}</h4>
              <span class="text-[9px] font-mono-code text-slate-400">RAKSHA-SETU 360 • POLICE VERIFIED</span>
            </div>
          </div>
          <span class="text-[10px] font-mono-code font-bold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/50">
            ${c.badgeId}
          </span>
        </div>

        <div class="flex items-start justify-between gap-3">
          <div class="space-y-1 text-xs text-slate-300 flex-1">
            <div class="font-extrabold text-sm text-white">${c.name} (${c.age} yrs)</div>
            <div class="text-[11px]"><span class="text-slate-400">Blood:</span> <span class="font-bold text-rose-300">${c.bloodGroup}</span></div>
            <div class="text-[11px]"><span class="text-slate-400">Primary Contact:</span> <span class="font-bold text-emerald-300 font-mono-code">${c.contact}</span></div>
            <div class="text-[11px]"><span class="text-slate-400">Guardian:</span> <span class="text-slate-200">${c.guardian}</span></div>
            <div class="text-[10px] text-amber-300 bg-amber-950/40 p-1 rounded border border-amber-500/30 mt-1">${c.medicalNote}</div>
          </div>

          <!-- Simulated High-Density QR Matrix -->
          <div class="w-20 h-20 bg-white rounded-lg p-1.5 flex flex-col items-center justify-center shrink-0 shadow-lg">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=RAKSHA-SETU-SOS:${c.badgeId}:${c.contact}" alt="QR" class="w-full h-full object-contain">
          </div>
        </div>

        <div class="border-t border-slate-800 pt-2 flex items-center justify-between text-[9px] font-mono-code text-slate-400">
          <span>SCAN IN EMERGENCY FOR 1-TAP SOS</span>
          <span class="text-emerald-400">VALID 2026-27 🟢</span>
        </div>
      </div>
    `;
  }
}

window.smartQR = new SmartQRGeneratorModule();
