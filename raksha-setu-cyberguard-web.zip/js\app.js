/**
 * RAKSHA-SETU 360 - Main Application Controller & View Orchestrator
 */

class AppController {
  constructor() {
    this.currentTab = 'simulation';
    this.currentTheme = 'dark';
    this.init();
  }

  init() {
    document.addEventListener('DOMContentLoaded', () => {
      this.bindEvents();
      this.renderCurrentTab();
      this.startTelemetryHeartbeat();
      window.smartQR.renderCardPreview();
      window.pilgrimGuide.renderFacilityGrid();
    });
  }

  bindEvents() {
    // Navigation Tabs
    document.querySelectorAll('[data-tab-target]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget.getAttribute('data-tab-target');
        this.switchTab(target);
      });
    });

    // Theme Switcher Button
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        this.toggleTheme();
      });
    }

    // Audio Mute Toggle
    const muteBtn = document.getElementById('mute-toggle-btn');
    if (muteBtn) {
      muteBtn.addEventListener('click', () => {
        window.soundEngine.isMuted = !window.soundEngine.isMuted;
        muteBtn.innerHTML = window.soundEngine.isMuted ? '🔇 Audio Muted' : '🔊 Audio Active';
        muteBtn.classList.toggle('text-rose-400', window.soundEngine.isMuted);
        muteBtn.classList.toggle('text-emerald-400', !window.soundEngine.isMuted);
      });
    }
  }

  toggleTheme() {
    const body = document.body;
    const btn = document.getElementById('theme-toggle-btn');
    
    if (this.currentTheme === 'dark') {
      this.currentTheme = 'day';
      body.classList.remove('dark');
      body.classList.add('theme-day');
      if (btn) btn.innerHTML = '☀️ Day Civic';
    } else if (this.currentTheme === 'day') {
      this.currentTheme = 'neon';
      body.classList.remove('theme-day');
      body.classList.add('theme-neon');
      if (btn) btn.innerHTML = '⚡ Neon Emergency';
    } else {
      this.currentTheme = 'dark';
      body.classList.remove('theme-neon');
      body.classList.add('dark');
      if (btn) btn.innerHTML = '🌙 Tactical HUD';
    }
    this.showToast(`Theme switched to ${this.currentTheme.toUpperCase()} mode`, "info");
  }

  switchTab(tabId) {
    this.currentTab = tabId;
    
    // Update Tab Buttons
    document.querySelectorAll('[data-tab-target]').forEach(btn => {
      const target = btn.getAttribute('data-tab-target');
      if (target === tabId) {
        btn.classList.add('bg-cyan-500/20', 'text-cyan-300', 'border-cyan-400/50');
        btn.classList.remove('text-slate-400', 'border-transparent');
      } else {
        btn.classList.remove('bg-cyan-500/20', 'text-cyan-300', 'border-cyan-400/50');
        btn.classList.add('text-slate-400', 'border-transparent');
      }
    });

    // Hide all tab contents
    document.querySelectorAll('.tab-view-content').forEach(section => {
      section.classList.add('hidden');
    });

    // Show active tab
    const activeSection = document.getElementById(`tab-view-${tabId}`);
    if (activeSection) {
      activeSection.classList.remove('hidden');
    }

    // Specific Initializers per tab
    if (tabId === 'command_center' || tabId === 'simulation') {
      setTimeout(() => {
        window.tacticalMap.init();
      }, 100);
    }
    if (tabId === 'helpdesk') {
      this.renderHelpdeskView();
    }
    if (tabId === 'citizen') {
      setTimeout(() => {
        window.safeRideModule.initPhoneMap();
      }, 150);
      window.smartQR.renderCardPreview();
      window.pilgrimGuide.renderFacilityGrid();
    }
    if (tabId === 'simulation') {
      this.renderSimulationView();
    }
    if (tabId === 'aistudio') {
      this.renderAIStudio();
    }
    if (tabId === 'antistampede') {
      this.renderAntiStampedeDashboard();
    }
    if (tabId === 'pttradio') {
      this.renderPTTRadioLogs();
    }
    if (tabId === 'cyber_resilience') {
      if (window.initCyberResilienceEngine) {
        window.initCyberResilienceEngine();
      }
    }
  }

  renderCurrentTab() {
    this.switchTab(this.currentTab);
  }

  showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    const borderColors = {
      info: 'border-cyan-500 text-cyan-200 bg-slate-900/95',
      warning: 'border-amber-500 text-amber-200 bg-amber-950/95',
      danger: 'border-rose-500 text-rose-200 bg-rose-950/95',
      success: 'border-emerald-500 text-emerald-200 bg-emerald-950/95'
    };

    const icons = { info: 'ℹ️', warning: '⚠️', danger: '🚨', success: '✅' };

    toast.className = `flex items-center gap-3 p-3.5 rounded-xl border backdrop-blur-md shadow-2xl transition-all transform duration-300 translate-y-2 opacity-0 text-xs sm:text-sm font-medium ${borderColors[type] || borderColors.info}`;
    toast.innerHTML = `
      <span class="text-base">${icons[type] || 'ℹ️'}</span>
      <div class="flex-1">${message}</div>
      <button class="text-slate-400 hover:text-white text-xs ml-2" onclick="this.parentElement.remove()">✕</button>
    `;

    toastContainer.appendChild(toast);
    requestAnimationFrame(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    });

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 5000);
  }

  startTelemetryHeartbeat() {
    setInterval(() => {
      const densityElem = document.getElementById('telemetry-density');
      const timeElem = document.getElementById('telemetry-clock');
      if (densityElem) {
        const jitter = (Math.random() * 2 - 1).toFixed(0);
        const val = Math.min(96, Math.max(68, 76 + parseInt(jitter)));
        densityElem.innerText = `${val}%`;
      }
      if (timeElem) {
        timeElem.innerText = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      }
    }, 1500);
  }

  // --- AI Studio Renderer ---
  renderAIStudio() {
    const camSelect = document.getElementById('aistudio-cam-select');
    if (camSelect) {
      camSelect.innerHTML = APP_DATA.cctvStreams.map(c => `
        <option value="${c.id}" ${c.id === window.aiMatcher.selectedCameraId ? 'selected' : ''}>${c.id}: ${c.name} (${c.density})</option>
      `).join('');
    }
  }

  runAIStudioComparison() {
    const camId = document.getElementById('aistudio-cam-select')?.value || "CAM-09";
    const reported = APP_DATA.missingCases[0];
    const candidate = {
      facialVector: true,
      clothingColor: "pink",
      hasYellowClip: true
    };

    const res = window.aiMatcher.compareDescriptors(reported, candidate);
    window.soundEngine.playMatchSuccess();

    const resultBox = document.getElementById('aistudio-result-box');
    if (resultBox) {
      resultBox.innerHTML = `
        <div class="glass-panel p-4 rounded-xl border ${res.isMatch ? 'border-pink-500 bg-pink-950/30' : 'border-slate-700'} space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono-code font-bold px-2 py-0.5 rounded ${res.isMatch ? 'bg-pink-900 text-pink-200' : 'bg-slate-800 text-slate-300'}">
              ${res.isMatch ? '🎯 POSITIVE BIOMETRIC MATCH' : 'NO MATCH'}
            </span>
            <span class="text-xs font-mono-code text-cyan-300 font-bold">${res.confidence} CONFIDENCE</span>
          </div>

          <div class="space-y-1.5 text-xs text-slate-300">
            ${res.breakdown.map(b => `
              <div class="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">${b.trait} (Weight: ${b.weight})</span>
                <span class="font-mono-code text-emerald-400 font-bold">${b.similarity}</span>
              </div>
            `).join('')}
          </div>

          <div class="flex items-center justify-between text-[11px] font-mono-code text-slate-400 pt-1">
            <span>Neural Vector: ${res.neuralVectorHash}</span>
            <span>Latency: ${res.inferenceLatencyMs}ms</span>
          </div>
        </div>
      `;
    }
  }

  // --- Anti-Stampede Automation Center Renderer ---
  renderAntiStampedeDashboard() {
    const stats = window.antiStampede.calculateHazardIndex();
    const hazardBadge = document.getElementById('stampede-hazard-badge');
    const inflowTotal = document.getElementById('stampede-inflow-total');
    const outflowTotal = document.getElementById('stampede-outflow-total');
    const ratioElem = document.getElementById('stampede-ratio-val');

    if (hazardBadge) {
      hazardBadge.innerText = stats.hazardLevel.replace(/_/g, ' ');
      hazardBadge.className = `px-2.5 py-1 rounded-full text-xs font-mono-code font-bold ${stats.hazardLevel.includes('CRITICAL') ? 'bg-rose-900 text-rose-200 border border-rose-500 animate-pulse' : 'bg-amber-900 text-amber-200 border border-amber-500'}`;
    }
    if (inflowTotal) inflowTotal.innerText = `${stats.inflowTotal} p/min`;
    if (outflowTotal) outflowTotal.innerText = `${stats.outflowTotal} p/min`;
    if (ratioElem) ratioElem.innerText = `${stats.bottleneckRatio}x Ratio`;
  }

  // --- PTT Radio Renderer ---
  renderPTTRadioLogs() {
    const container = document.getElementById('ptt-radio-logs');
    if (!container) return;

    container.innerHTML = window.pttRadio.radioLogs.map(l => `
      <div class="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs space-y-1">
        <div class="flex items-center justify-between">
          <span class="font-mono-code font-bold text-cyan-300">${l.channel} • ${l.sender}</span>
          <span class="text-[10px] font-mono-code text-slate-400">${l.time}</span>
        </div>
        <p class="text-slate-200">${l.message}</p>
      </div>
    `).join('');
  }

  sendPTTMessage() {
    const input = document.getElementById('ptt-input-text');
    if (!input || !input.value.trim()) return;

    const res = window.pttRadio.stopTransmit(input.value);
    input.value = '';
    this.renderPTTRadioLogs();
    this.showToast(`📻 Radio transmission dispatched on ${res.channel}`, "info");
  }

  // --- Helpdesk Dockets ---
  renderHelpdeskView() {
    const container = document.getElementById('helpdesk-dockets-list');
    if (!container) return;

    container.innerHTML = APP_DATA.missingCases.map(item => `
      <div class="glass-panel p-4 rounded-xl border ${item.status === 'REUNITED' ? 'border-emerald-500/40 bg-emerald-950/20' : item.status === 'AI_MATCH_LOCATED' ? 'border-pink-500/50 bg-pink-950/20 animate-pulse-glow' : 'border-slate-700/50'} flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="flex items-center gap-3.5">
          <div class="relative w-14 h-14 rounded-xl overflow-hidden border-2 ${item.status === 'AI_MATCH_LOCATED' ? 'border-pink-400' : 'border-cyan-400/60'} shadow-md">
            <img src="${item.avatar}" alt="${item.name}" class="w-full h-full object-cover">
            ${item.status !== 'REUNITED' ? '<div class="volunteer-watermark-overlay absolute inset-0"></div>' : ''}
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h4 class="font-bold text-base text-white">${item.name}</h4>
              <span class="text-xs px-2 py-0.5 rounded font-mono-code font-bold ${item.status === 'REUNITED' ? 'bg-emerald-900 text-emerald-300' : item.status === 'AI_MATCH_LOCATED' ? 'bg-pink-900 text-pink-200' : 'bg-amber-900 text-amber-200'}">
                ${item.status.replace(/_/g, ' ')}
              </span>
            </div>
            <p class="text-xs text-slate-300 mt-0.5">
              Age: <span class="font-semibold text-white">${item.age} yrs</span> • Hometown: <span class="text-cyan-300 font-medium">${item.hometown}</span> • Reported: <span class="font-mono-code text-slate-400">${item.reportedTime} (${item.reportedAtDesk})</span>
            </p>
            <p class="text-xs text-slate-400 mt-1">
              Dress: <span class="text-slate-200 font-medium">${item.appearance.dress}</span> • ${item.appearance.accessories}
            </p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2 self-stretch md:self-auto justify-end">
          ${item.status === 'AI_MATCH_LOCATED' ? `
            <button onclick="window.app.openReunionModal('${item.id}')" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 transition">
              <span>🤝 Parent OTP Handover</span>
            </button>
          ` : ''}
          ${item.status === 'SEARCHING' ? `
            <button onclick="window.app.showToast('📡 Watermarked Alert pushed to 450 NSS/Police tablets for ${item.name}', 'info'); window.soundEngine.playPAChime();" class="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium transition">
              📢 Push Volunteer Alert
            </button>
          ` : ''}
          <button onclick="window.app.showToast('📋 Docket #${item.id} Details Synced', 'info')" class="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded-lg text-xs font-medium transition">
            View Docket
          </button>
        </div>
      </div>
    `).join('');
  }

  // --- Simulation View ---
  renderSimulationView() {
    const scenario = window.simEngine.getCurrentScenarioData();
    const step = window.simEngine.getCurrentStepData();
    const curIdx = window.simEngine.currentStep;
    const totalSteps = scenario.steps.length;

    const titleElem = document.getElementById('sim-scenario-title');
    const subtitleElem = document.getElementById('sim-scenario-subtitle');
    const progressElem = document.getElementById('sim-progress-indicator');
    const stepCardElem = document.getElementById('sim-current-step-card');

    if (titleElem) titleElem.innerText = scenario.title;
    if (subtitleElem) subtitleElem.innerText = scenario.subtitle;
    if (progressElem) {
      progressElem.innerHTML = scenario.steps.map((s, idx) => `
        <button onclick="window.simEngine.goToStep(${idx}, window.app); window.app.renderSimulationView();" class="flex-1 py-1.5 px-2 text-center text-xs font-mono-code font-bold rounded-md transition ${idx === curIdx ? 'bg-cyan-500 text-slate-950 shadow-md' : idx < curIdx ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'}">
          ${s.time}
        </button>
      `).join('');
    }

    if (stepCardElem) {
      stepCardElem.innerHTML = `
        <div class="space-y-4">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-full text-xs font-bold font-mono-code ${step.badgeColor === 'rose' ? 'bg-rose-950 text-rose-300 border border-rose-500/50' : step.badgeColor === 'amber' ? 'bg-amber-950 text-amber-300 border border-amber-500/50' : step.badgeColor === 'emerald' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50' : 'bg-cyan-950 text-cyan-300 border border-cyan-500/50'}">
              ${step.badge}
            </span>
            <span class="text-xs font-mono-code text-slate-400">Step ${curIdx + 1} of ${totalSteps} (${step.time})</span>
          </div>

          <div>
            <h3 class="text-lg font-bold text-white">${step.title}</h3>
            <p class="text-sm text-slate-300 mt-1 leading-relaxed">${step.description}</p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div class="p-3 rounded-lg bg-rose-950/30 border border-rose-500/30 text-xs text-rose-200">
              <span class="font-bold text-rose-300 block mb-1">❌ ${step.traditionalGap.split(':')[0]}</span>
              ${step.traditionalGap.split(':')[1]}
            </div>
            <div class="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-200">
              <span class="font-bold text-emerald-300 block mb-1">✅ ${step.solutionFix.split(':')[0]}</span>
              ${step.solutionFix.split(':')[1]}
            </div>
          </div>
        </div>
      `;
    }
  }

  // --- Modals ---
  openCCTVModal(camId) {
    const cam = APP_DATA.cctvStreams.find(c => c.id === camId) || APP_DATA.cctvStreams[0];
    const modal = document.getElementById('cctv-modal');
    if (!modal) return;

    document.getElementById('cctv-modal-title').innerText = `${cam.id} • ${cam.name}`;
    document.getElementById('cctv-modal-zone').innerText = cam.zone;
    document.getElementById('cctv-modal-density').innerText = cam.density;
    document.getElementById('cctv-modal-flags').innerText = cam.aiFlags.join(' | ');

    modal.classList.remove('hidden');
    modal.classList.add('flex');
    window.soundEngine.playPAChime();
  }

  closeCCTVModal() {
    const modal = document.getElementById('cctv-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  openPAModal() {
    const modal = document.getElementById('pa-broadcast-modal');
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('flex');
    }
  }

  closePAModal() {
    const modal = document.getElementById('pa-broadcast-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  openRegisterMissingModal() {
    const modal = document.getElementById('register-missing-modal');
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('flex');
    }
  }

  closeRegisterMissingModal() {
    const modal = document.getElementById('register-missing-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  openReunionModal(caseId) {
    const targetCase = APP_DATA.missingCases.find(c => c.id === caseId);
    if (!targetCase) return;

    const modal = document.getElementById('reunion-modal');
    if (!modal) return;

    document.getElementById('reunion-case-id').innerText = targetCase.id;
    document.getElementById('reunion-child-name').innerText = targetCase.name;
    document.getElementById('reunion-parents').innerText = targetCase.parentsName;
    document.getElementById('reunion-contact').innerText = targetCase.contact;

    modal.setAttribute('data-active-case-id', caseId);
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  closeReunionModal() {
    const modal = document.getElementById('reunion-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  confirmReunion() {
    const modal = document.getElementById('reunion-modal');
    const caseId = modal.getAttribute('data-active-case-id');
    const otpInput = document.getElementById('reunion-otp-input')?.value || "4491";

    const res = window.helpDeskModule.markReunited(caseId, otpInput);
    if (res) {
      this.closeReunionModal();
      this.showToast(`🎉 Verified Handover Complete: ${res.name} reunited with family!`, "success");
      this.renderHelpdeskView();
    }
  }
}

window.app = new AppController();
