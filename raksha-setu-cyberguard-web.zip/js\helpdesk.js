﻿/**
 * RAKSHA-SETU 360 - First Responder & Helpdesk Digital Station Logic
 */

class HelpDeskModule {
  constructor() {
    this.currentDeskId = "HD-02"; // Helpdesk 2 (East Gate Plaza)
    this.activeDockets = [...APP_DATA.missingCases];
  }

  registerMissingChild(data) {
    const docketId = "MP-DKB-2026-00" + Math.floor(50 + Math.random() * 50);
    const newCase = {
      id: docketId,
      name: data.name,
      age: parseInt(data.age) || 6,
      gender: data.gender || "Female",
      hometown: data.hometown || "Chandrapur",
      reportedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timeElapsedMins: 1,
      reportedAtDesk: `${this.currentDeskId} (${APP_DATA.helpDesks.find(d => d.id === this.currentDeskId)?.name || 'Field Desk'})`,
      parentsName: data.parentsName || "Parent",
      contact: data.contact || "+91 94231 00000",
      appearance: {
        dress: data.dress || "Pink Frock",
        accessories: data.accessories || "Hair clip",
        height: data.height || "3 ft 6 in",
        complexion: data.complexion || "Fair",
        identifyingMark: data.marks || "None"
      },
      status: "SEARCHING",
      avatar: data.photoUrl || "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=200&auto=format&fit=crop&q=80",
      broadcastScope: "Protected Volunteer Channel (Watermarked Cryptographic Push)"
    };

    APP_DATA.missingCases.unshift(newCase);
    window.soundEngine.playMatchSuccess();
    return newCase;
  }

  markReunited(caseId, parentOtp = "4491") {
    const targetCase = APP_DATA.missingCases.find(c => c.id === caseId);
    if (targetCase) {
      targetCase.status = "REUNITED";
      targetCase.reunitedTime = new Date().toLocaleTimeString();
      targetCase.verifiedOfficer = "PSI V. Patil (HD-03 Gate 3)";
      targetCase.handoverOtp = parentOtp;
      window.soundEngine.playMatchSuccess();
      return targetCase;
    }
    return null;
  }
}

window.helpDeskModule = new HelpDeskModule();
