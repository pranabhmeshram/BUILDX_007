/**
 * RAKSHA-SETU 360 - Module 9: Cyber Resilience & Critical Infrastructure Sentinel
 * Protects Smart City Digital Infrastructure: Power Grid, Water Supply, Transportation & Public Services.
 */

class CyberResilienceEngine {
  constructor() {
    this.subsystems = {
      power_grid: {
        id: 'power_grid',
        name: 'Smart Power Grid SCADA',
        icon: '⚡',
        status: 'NOMINAL', // NOMINAL, WARNING, CRITICAL, ISOLATED
        voltage: 220.4, // kV
        frequency: 50.02, // Hz
        loadPct: 68,
        packetLoss: 0.1, // %
        scadaHealth: 100, // %
        airGapped: false,
        attack: null
      },
      water_supply: {
        id: 'water_supply',
        name: 'Water Supply PLC Actuators',
        icon: '💧',
        status: 'NOMINAL',
        chlorinePpm: 1.8,
        phLevel: 7.2,
        flowRate: 14.5, // m3/s
        plcLockout: false,
        firmwareHash: 'a7f9b28c0d1e2f3a',
        firmwareTampered: false,
        attack: null
      },
      transportation: {
        id: 'transportation',
        name: 'Metro Transit & Traffic Signal Relays',
        icon: '🚆',
        status: 'NOMINAL',
        metroLine1Signal: 'GREEN',
        metroLine2Signal: 'GREEN',
        trafficRelayLatency: 12, // ms
        spoofingDetected: false,
        attack: null
      },
      public_services: {
        id: 'public_services',
        name: 'Emergency Dispatch (911/112 CAD)',
        icon: '🚑',
        status: 'NOMINAL',
        activeDispatchers: 42,
        networkBandwidth: 98.4, // Mbps
        satFailoverActive: false,
        attack: null
      }
    };

    this.activeAttacks = [];
    this.logs = [];
    this.anomalyScore = 2; // 0 - 100%
    this.threatLevel = 'LOW'; // LOW, ELEVATED, SEVERE, CRITICAL
    this.autoHealEnabled = true;
    this.telemetryTimer = null;
  }

  init() {
    this.addLog('SYSTEM_INIT', 'Zero-Trust Sentinel active. Continuous SCADA payload inspection online.', 'INFO');
    this.render();
    this.startTelemetryLoop();
  }

  startTelemetryLoop() {
    if (this.telemetryTimer) clearInterval(this.telemetryTimer);
    this.telemetryTimer = setInterval(() => {
      this.updateTelemetryFluctuations();
      this.evaluateAnomalyScore();
      this.renderTelemetryHUD();
    }, 2000);
  }

  updateTelemetryFluctuations() {
    // Power Grid
    if (this.subsystems.power_grid.status === 'NOMINAL') {
      this.subsystems.power_grid.voltage = +(220 + (Math.random() * 0.8 - 0.4)).toFixed(2);
      this.subsystems.power_grid.frequency = +(50 + (Math.random() * 0.08 - 0.04)).toFixed(2);
      this.subsystems.power_grid.packetLoss = +(Math.random() * 0.3).toFixed(1);
    } else if (this.subsystems.power_grid.attack === 'FDIA') {
      this.subsystems.power_grid.voltage = +(248.5 + (Math.random() * 5)).toFixed(2);
      this.subsystems.power_grid.frequency = +(47.2 - (Math.random() * 0.5)).toFixed(2);
      this.subsystems.power_grid.packetLoss = +(14.5 + Math.random() * 5).toFixed(1);
    }

    // Water Supply
    if (this.subsystems.water_supply.status === 'NOMINAL') {
      this.subsystems.water_supply.chlorinePpm = +(1.8 + (Math.random() * 0.1 - 0.05)).toFixed(2);
      this.subsystems.water_supply.phLevel = +(7.2 + (Math.random() * 0.1 - 0.05)).toFixed(2);
    } else if (this.subsystems.water_supply.attack === 'RANSOMWARE') {
      this.subsystems.water_supply.chlorinePpm = +(4.8 + Math.random() * 0.5).toFixed(2);
      this.subsystems.water_supply.phLevel = +(9.4 + Math.random() * 0.3).toFixed(2);
    }

    // Transportation
    if (this.subsystems.transportation.attack === 'MITM') {
      this.subsystems.transportation.trafficRelayLatency = Math.floor(450 + Math.random() * 200);
    } else {
      this.subsystems.transportation.trafficRelayLatency = Math.floor(10 + Math.random() * 8);
    }

    // Public Services
    if (this.subsystems.public_services.attack === 'DDOS') {
      this.subsystems.public_services.networkBandwidth = +(12.1 + Math.random() * 5).toFixed(1);
    } else {
      this.subsystems.public_services.networkBandwidth = +(97.5 + Math.random() * 2).toFixed(1);
    }
  }

  evaluateAnomalyScore() {
    let score = 2;
    this.activeAttacks.forEach(att => {
      if (att === 'DDOS') score += 25;
      if (att === 'RANSOMWARE') score += 30;
      if (att === 'MITM') score += 20;
      if (att === 'FDIA') score += 25;
    });

    this.anomalyScore = Math.min(100, score);
    if (this.anomalyScore < 10) this.threatLevel = 'DEFCON 5 (LOW)';
    else if (this.anomalyScore < 40) this.threatLevel = 'DEFCON 3 (ELEVATED)';
    else if (this.anomalyScore < 75) this.threatLevel = 'DEFCON 2 (SEVERE)';
    else this.threatLevel = 'DEFCON 1 (CRITICAL)';

    // Update global badge if app exists
    const badgeEl = document.getElementById('cyber-threat-badge');
    if (badgeEl) {
      badgeEl.innerText = `${this.threatLevel} (${this.anomalyScore}% ANOMALY)`;
      badgeEl.className = `px-2.5 py-1 rounded-full text-xs font-mono-code font-bold ${
        this.anomalyScore > 50 ? 'bg-rose-950 text-rose-300 border border-rose-500 animate-pulse' : 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
      }`;
    }
  }

  // Multi-Vector Attack Simulator Triggers
  triggerSimultaneousAttack() {
    this.activeAttacks = ['DDOS', 'RANSOMWARE', 'MITM', 'FDIA'];
    
    // Subsystem 1: Power Grid FDIA
    this.subsystems.power_grid.status = 'CRITICAL';
    this.subsystems.power_grid.attack = 'FDIA';
    this.subsystems.power_grid.scadaHealth = 32;

    // Subsystem 2: Water Supply PLC Ransomware
    this.subsystems.water_supply.status = 'CRITICAL';
    this.subsystems.water_supply.attack = 'RANSOMWARE';
    this.subsystems.water_supply.plcLockout = true;
    this.subsystems.water_supply.firmwareTampered = true;
    this.subsystems.water_supply.firmwareHash = 'CORRUPTED_HASH_339x';

    // Subsystem 3: Transportation MitM
    this.subsystems.transportation.status = 'WARNING';
    this.subsystems.transportation.attack = 'MITM';
    this.subsystems.transportation.spoofingDetected = true;
    this.subsystems.transportation.metroLine1Signal = 'SPOOFED_GREEN (CONFLICT)';

    // Subsystem 4: Public Services DDoS
    this.subsystems.public_services.status = 'CRITICAL';
    this.subsystems.public_services.attack = 'DDOS';

    this.addLog('ATTACK_VECTOR_INIT', '🔴 MULTI-VECTOR SIMULTANEOUS CYBER ATTACK LAUNCHED ACROSS SMART CITY NODES!', 'CRITICAL');
    this.addLog('POWER_GRID', 'FDIA Attack: Artificial voltage spike (253.2kV) detected on Substation B SCADA relay.', 'WARN');
    this.addLog('WATER_SUPPLY', 'Ransomware Alert: Unsigned PLC firmware payload injected! Chlorination actuators locked.', 'CRITICAL');
    this.addLog('TRANSPORT', 'MitM Spoofing: Signal conflict on Metro Line 1 relay! Latency >480ms.', 'WARN');
    this.addLog('DISPATCH', 'DDoS Volumetric Flood: 85,000 req/sec attacking 911 CAD API Gateway.', 'CRITICAL');

    if (window.audioEngine) {
      window.audioEngine.playAlertSiren('CRITICAL_STAMPEDE');
    }

    this.render();
  }

  // Mitigation Actions
  isolatePowerGridAirGap() {
    this.subsystems.power_grid.airGapped = true;
    this.subsystems.power_grid.status = 'ISOLATED';
    this.subsystems.power_grid.voltage = 220.0;
    this.subsystems.power_grid.frequency = 50.0;
    this.subsystems.power_grid.scadaHealth = 95;
    this.subsystems.power_grid.attack = null;
    this.activeAttacks = this.activeAttacks.filter(a => a !== 'FDIA');
    
    this.addLog('POWER_GRID', '⚡ AIR-GAP ACTIVATED: Power grid SCADA isolated into offline self-healing microgrid.', 'SUCCESS');
    this.render();
  }

  rollbackWaterFirmware() {
    this.subsystems.water_supply.firmwareTampered = false;
    this.subsystems.water_supply.firmwareHash = 'a7f9b28c0d1e2f3a (SHA-256 VERIFIED)';
    this.subsystems.water_supply.plcLockout = false;
    this.subsystems.water_supply.status = 'NOMINAL';
    this.subsystems.water_supply.chlorinePpm = 1.8;
    this.subsystems.water_supply.phLevel = 7.2;
    this.subsystems.water_supply.attack = null;
    this.activeAttacks = this.activeAttacks.filter(a => a !== 'RANSOMWARE');

    this.addLog('WATER_SUPPLY', '💧 FIRMWARE ROLLBACK: Cryptographic SHA-256 state restored. Water PLC actuators unlocked.', 'SUCCESS');
    this.render();
  }

  mitigateTransportMitM() {
    this.subsystems.transportation.spoofingDetected = false;
    this.subsystems.transportation.metroLine1Signal = 'GREEN (ENCRYPTED)';
    this.subsystems.transportation.status = 'NOMINAL';
    this.subsystems.transportation.trafficRelayLatency = 12;
    this.subsystems.transportation.attack = null;
    this.activeAttacks = this.activeAttacks.filter(a => a !== 'MITM');

    this.addLog('TRANSPORT', '🚆 MITM NEUTRALIZED: Re-keyed TLS 1.3 mTLS tunnels across Metro Transit relays.', 'SUCCESS');
    this.render();
  }

  activateSatFailover() {
    this.subsystems.public_services.satFailoverActive = true;
    this.subsystems.public_services.networkBandwidth = 100.0;
    this.subsystems.public_services.status = 'NOMINAL';
    this.subsystems.public_services.attack = null;
    this.activeAttacks = this.activeAttacks.filter(a => a !== 'DDOS');

    this.addLog('DISPATCH', '🚑 SAT FAILOVER: 911 CAD Dispatch traffic rerouted to Starlink Military Mesh Satellite.', 'SUCCESS');
    this.render();
  }

  fullAutoHealRecovery() {
    this.isolatePowerGridAirGap();
    this.rollbackWaterFirmware();
    this.mitigateTransportMitM();
    this.activateSatFailover();

    this.activeAttacks = [];
    this.anomalyScore = 0;
    this.threatLevel = 'DEFCON 5 (NOMINAL)';

    this.addLog('AUTO_HEAL', '🛡️ FULL DISASTER RECOVERY COMPLETE: All Smart City critical infrastructures stabilized!', 'SUCCESS');
    
    if (window.confetti) {
      window.confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    
    this.render();
  }

  addLog(source, msg, type = 'INFO') {
    const timestamp = new Date().toLocaleTimeString();
    this.logs.unshift({ timestamp, source, msg, type });
    if (this.logs.length > 50) this.logs.pop();
    this.renderTerminalLogs();
  }

  renderTerminalLogs() {
    const termEl = document.getElementById('cyber-terminal-logs');
    if (!termEl) return;
    termEl.innerHTML = this.logs.map(log => {
      let colorClass = 'text-slate-300';
      if (log.type === 'CRITICAL') colorClass = 'text-rose-400 font-bold';
      else if (log.type === 'WARN') colorClass = 'text-amber-300';
      else if (log.type === 'SUCCESS') colorClass = 'text-emerald-300 font-semibold';
      return `<div class="text-[11px] font-mono-code leading-relaxed border-b border-slate-900/60 pb-1">
        <span class="text-slate-500">[${log.timestamp}]</span>
        <span class="text-cyan-400 font-bold">[${log.source}]</span>
        <span class="${colorClass}">${log.msg}</span>
      </div>`;
    }).join('');
  }

  renderTelemetryHUD() {
    // Live text telemetry updates
    const vEl = document.getElementById('cyber-pow-volts');
    if (vEl) vEl.innerText = `${this.subsystems.power_grid.voltage} kV`;
    const fEl = document.getElementById('cyber-pow-freq');
    if (fEl) fEl.innerText = `${this.subsystems.power_grid.frequency} Hz`;
    const wEl = document.getElementById('cyber-wat-chlor');
    if (wEl) wEl.innerText = `${this.subsystems.water_supply.chlorinePpm} ppm`;
    const tEl = document.getElementById('cyber-tra-lat');
    if (tEl) tEl.innerText = `${this.subsystems.transportation.trafficRelayLatency} ms`;
  }

  render() {
    this.evaluateAnomalyScore();
    this.renderTerminalLogs();
    this.renderTelemetryHUD();

    const container = document.getElementById('cyber-subsystem-cards');
    if (!container) return;

    container.innerHTML = Object.values(this.subsystems).map(sub => {
      let statusBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">NOMINAL</span>`;
      let borderClass = 'border-slate-800';

      if (sub.status === 'CRITICAL') {
        statusBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-rose-950 text-rose-300 border border-rose-500 animate-pulse">ATTACKED</span>`;
        borderClass = 'border-rose-500/80 bg-rose-950/20';
      } else if (sub.status === 'WARNING') {
        statusBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-amber-950 text-amber-300 border border-amber-500/40">WARNING</span>`;
        borderClass = 'border-amber-500/60 bg-amber-950/10';
      } else if (sub.status === 'ISOLATED') {
        statusBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/40">AIR-GAPPED</span>`;
        borderClass = 'border-cyan-500/60 bg-cyan-950/10';
      }

      return `
        <div class="glass-panel p-4 rounded-xl border ${borderClass} space-y-3 transition">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="text-2xl">${sub.icon}</span>
              <div>
                <h4 class="font-bold text-sm text-slate-100">${sub.name}</h4>
                <p class="text-[10px] text-slate-400 font-mono-code">ID: ${sub.id.toUpperCase()}</p>
              </div>
            </div>
            ${statusBadge}
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs font-mono-code pt-1 border-t border-slate-800/80">
            ${sub.id === 'power_grid' ? `
              <div><span class="text-slate-400">Voltage:</span> <span id="cyber-pow-volts" class="font-bold text-cyan-300">${sub.voltage} kV</span></div>
              <div><span class="text-slate-400">Freq:</span> <span id="cyber-pow-freq" class="font-bold text-amber-300">${sub.frequency} Hz</span></div>
              <div><span class="text-slate-400">SCADA:</span> <span class="font-bold ${sub.scadaHealth < 50 ? 'text-rose-400' : 'text-emerald-400'}">${sub.scadaHealth}%</span></div>
              <div><span class="text-slate-400">Mode:</span> <span class="font-bold text-cyan-400">${sub.airGapped ? 'Air-Gapped' : 'Online Grid'}</span></div>
            ` : ''}

            ${sub.id === 'water_supply' ? `
              <div><span class="text-slate-400">Chlorine:</span> <span id="cyber-wat-chlor" class="font-bold text-cyan-300">${sub.chlorinePpm} ppm</span></div>
              <div><span class="text-slate-400">pH Level:</span> <span class="font-bold text-slate-200">${sub.phLevel}</span></div>
              <div><span class="text-slate-400">PLC Lock:</span> <span class="font-bold ${sub.plcLockout ? 'text-rose-400' : 'text-emerald-400'}">${sub.plcLockout ? 'LOCKED' : 'READY'}</span></div>
              <div><span class="text-slate-400">FW Hash:</span> <span class="text-[9px] text-slate-300 truncate">${sub.firmwareHash}</span></div>
            ` : ''}

            ${sub.id === 'transportation' ? `
              <div><span class="text-slate-400">Line 1:</span> <span class="font-bold ${sub.metroLine1Signal.includes('SPOOFED') ? 'text-rose-400' : 'text-emerald-400'}">${sub.metroLine1Signal}</span></div>
              <div><span class="text-slate-400">Latency:</span> <span id="cyber-tra-lat" class="font-bold text-amber-300">${sub.trafficRelayLatency} ms</span></div>
              <div><span class="text-slate-400">Spoofing:</span> <span class="font-bold ${sub.spoofingDetected ? 'text-rose-400' : 'text-emerald-400'}">${sub.spoofingDetected ? 'DETECTED' : 'NONE'}</span></div>
              <div><span class="text-slate-400">Tunnel:</span> <span class="text-cyan-300">mTLS 1.3</span></div>
            ` : ''}

            ${sub.id === 'public_services' ? `
              <div><span class="text-slate-400">CAD Dispatch:</span> <span class="font-bold text-emerald-400">${sub.activeDispatchers} Desks</span></div>
              <div><span class="text-slate-400">Bandwidth:</span> <span class="font-bold text-cyan-300">${sub.networkBandwidth} Mbps</span></div>
              <div><span class="text-slate-400">Route:</span> <span class="font-bold text-amber-300">${sub.satFailoverActive ? 'SAT MESH' : 'FIBER BACKBONE'}</span></div>
              <div><span class="text-slate-400">DDoS Protection:</span> <span class="text-emerald-400">ACTIVE</span></div>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  }
}

// Global initialization helper
window.initCyberResilienceEngine = function() {
  if (!window.cyberEngine) {
    window.cyberEngine = new CyberResilienceEngine();
  }
  window.cyberEngine.init();
};
