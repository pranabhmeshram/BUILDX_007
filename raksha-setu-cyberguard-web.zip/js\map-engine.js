﻿/**
 * RAKSHA-SETU 360 - Tactical GIS Mapping & Telemetry Visualization Engine
 */

class TacticalMapEngine {
  constructor(mapContainerId = 'tactical-map') {
    this.containerId = mapContainerId;
    this.map = null;
    this.markers = {};
    this.heatLayers = [];
    this.routePolylines = [];
    this.zonePolygons = [];
  }

  init() {
    const container = document.getElementById(this.containerId);
    if (!container) return;

    // Center on Deekshabhoomi, Nagpur
    const centerCoords = APP_DATA.geoCenter; // [21.1278, 79.0667]

    if (this.map) {
      this.map.remove();
    }

    this.map = L.map(this.containerId, {
      center: centerCoords,
      zoom: 16,
      zoomControl: false,
      attributionControl: false
    });

    // Add High-Tech Tactical Dark Tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      subdomains: 'abcd'
    }).addTo(this.map);

    // Add Top-Right Clean Zoom Controls
    L.control.zoom({ position: 'topright' }).addTo(this.map);

    // Draw Deekshabhoomi Perimeter Boundary
    this.drawPerimeter();

    // Render POIs, Helpdesks, CCTVs, and Crowd Zones
    this.renderLandmarks();
    this.renderHelpDesks();
    this.renderCCTVs();
    this.renderCrowdDensityZones();
  }

  drawPerimeter() {
    const perimeterCoords = [
      [21.1305, 79.0655],
      [21.1302, 79.0688],
      [21.1285, 79.0700],
      [21.1265, 79.0695],
      [21.1250, 79.0675],
      [21.1255, 79.0645],
      [21.1275, 79.0635],
      [21.1298, 79.0642]
    ];

    const perimeter = L.polygon(perimeterCoords, {
      color: '#06b6d4',
      weight: 2,
      dashArray: '6, 6',
      fillColor: '#06b6d4',
      fillOpacity: 0.05
    }).addTo(this.map);

    perimeter.bindTooltip("Deekshabhoomi Holy Sanctuary Perimeter (6.5 Lakh Footfall Zone)", {
      permanent: false,
      direction: "center",
      className: "glass-panel text-xs text-cyan-300 font-mono-code"
    });
  }

  renderLandmarks() {
    APP_DATA.landmarks.forEach(item => {
      let iconColor = '#38bdf8';
      let iconHtml = '🏛️';
      let pulseClass = '';

      if (item.type === 'monument') {
        iconHtml = '☸️';
        iconColor = '#fbbf24';
      } else if (item.type === 'stage') {
        iconHtml = '🎤';
        iconColor = '#ec4899';
      } else if (item.type === 'exit') {
        iconHtml = '🚪';
        if (item.status === 'bottleneck_alert') {
          iconColor = '#ef4444';
          pulseClass = 'animate-pulse-glow';
        } else if (item.status === 'green_channel') {
          iconColor = '#10b981';
        } else {
          iconColor = '#f59e0b';
        }
      } else if (item.type === 'medical') {
        iconHtml = '🏥';
        iconColor = '#10b981';
      } else if (item.type === 'hq') {
        iconHtml = '📡';
        iconColor = '#6366f1';
      }

      const customIcon = L.divIcon({
        className: 'custom-tactical-pin',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-lg ${pulseClass}" style="background: rgba(15, 23, 42, 0.9); border: 2px solid ${iconColor};">
              ${iconHtml}
            </div>
            ${item.crowdLevel ? `<span class="absolute -bottom-2 text-[9px] font-mono-code px-1 rounded font-bold ${item.crowdLevel > 80 ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-cyan-300'}">${item.crowdLevel}%</span>` : ''}
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const marker = L.marker(item.coords, { icon: customIcon }).addTo(this.map);
      marker.bindPopup(`
        <div class="p-2 space-y-1">
          <div class="font-bold text-sm text-cyan-400 flex items-center gap-1.5">${iconHtml} ${item.name}</div>
          <div class="text-xs text-slate-300">Type: <span class="uppercase font-mono-code text-slate-400">${item.type}</span></div>
          ${item.crowdLevel ? `<div class="text-xs">Density: <span class="font-bold ${item.crowdLevel > 80 ? 'text-rose-400' : 'text-emerald-400'}">${item.crowdLevel}% Capacity</span></div>` : ''}
          ${item.status ? `<div class="text-xs">Status: <span class="font-mono-code font-bold uppercase ${item.status.includes('alert') ? 'text-rose-400' : 'text-emerald-400'}">${item.status.replace('_', ' ')}</span></div>` : ''}
          ${item.flowRate ? `<div class="text-xs text-slate-400 font-mono-code">Throughput: ${item.flowRate} persons/min</div>` : ''}
        </div>
      `);

      this.markers[item.id] = marker;
    });
  }

  renderHelpDesks() {
    APP_DATA.helpDesks.forEach(desk => {
      const icon = L.divIcon({
        className: 'custom-tactical-pin',
        html: `
          <div class="w-7 h-7 rounded-lg bg-blue-950/90 border border-blue-400 flex items-center justify-center text-xs text-blue-300 font-bold shadow-md shadow-blue-500/20">
            ℹ️
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      // Offset slightly to spread out
      const deskCoords = APP_DATA.landmarks.find(l => l.name.includes(desk.name.split(' ')[0]))?.coords || [21.1278 + (Math.random() - 0.5) * 0.003, 79.0667 + (Math.random() - 0.5) * 0.003];

      const marker = L.marker(deskCoords, { icon }).addTo(this.map);
      marker.bindPopup(`
        <div class="p-2 space-y-1.5">
          <div class="font-bold text-sm text-blue-400 flex items-center gap-1">🛡️ ${desk.name}</div>
          <div class="text-xs text-slate-300">In-Charge: <span class="font-semibold text-white">${desk.officer}</span></div>
          <div class="text-xs text-slate-400 font-mono-code">Direct Hotline: ${desk.phone}</div>
          <div class="flex items-center gap-2 pt-1">
            <span class="px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-500 text-emerald-300 text-[10px] font-mono-code">SYNCED 🟢</span>
            <span class="text-xs text-slate-300">${desk.activeCases} Active Cases</span>
          </div>
        </div>
      `);
      this.markers[desk.id] = marker;
    });
  }

  renderCCTVs() {
    APP_DATA.cctvStreams.forEach(cam => {
      let borderCol = '#06b6d4';
      let pulseAnim = '';
      if (cam.status === 'match_alert') {
        borderCol = '#ec4899';
        pulseAnim = 'animate-pulse-glow';
      } else if (cam.status === 'danger' || cam.status === 'warning') {
        borderCol = '#ef4444';
      }

      const icon = L.divIcon({
        className: 'custom-tactical-pin',
        html: `
          <div class="relative w-7 h-7 rounded-md bg-slate-900 border-2 flex items-center justify-center text-xs shadow-lg ${pulseAnim}" style="border-color: ${borderCol};">
            📹
            ${cam.status === 'match_alert' ? `<span class="absolute -top-1 -right-1 w-2.5 h-2.5 bg-pink-500 rounded-full animate-ping"></span>` : ''}
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const marker = L.marker(cam.coords, { icon }).addTo(this.map);
      marker.bindPopup(`
        <div class="p-2 space-y-1">
          <div class="font-bold text-xs text-cyan-300 font-mono-code">📹 ${cam.id}: ${cam.name}</div>
          <div class="text-xs text-slate-300">Zone: <span class="text-white">${cam.zone}</span></div>
          <div class="text-xs">Density: <span class="font-bold ${cam.density.includes('Critical') || cam.density.includes('Severe') ? 'text-rose-400' : 'text-emerald-400'} font-mono-code">${cam.density}</span></div>
          <div class="text-[11px] text-amber-300 bg-amber-950/40 p-1 rounded border border-amber-500/30">AI Tags: ${cam.aiFlags.join(', ')}</div>
          <button onclick="window.app.openCCTVModal('${cam.id}')" class="w-full mt-2 py-1 px-2 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium transition flex items-center justify-center gap-1">
            <span>View Live AI Feed</span> ↗
          </button>
        </div>
      `);
      this.markers[cam.id] = marker;
    });
  }

  renderCrowdDensityZones() {
    // Clear previous zones
    this.zonePolygons.forEach(p => p.remove());
    this.zonePolygons = [];

    // Bottleneck Zone at Exit 2
    const exit2Zone = L.circle([21.1270, 79.0690], {
      radius: 45,
      color: '#f43f5e',
      fillColor: '#f43f5e',
      fillOpacity: 0.35,
      weight: 1.5,
      className: 'animate-pulse'
    }).addTo(this.map);
    exit2Zone.bindTooltip("Exit 2 Corridor: 89% Critical Surge", { className: 'glass-panel text-xs text-rose-300 font-mono-code' });
    this.zonePolygons.push(exit2Zone);

    // Bottleneck Zone at Exit 4
    const exit4Zone = L.circle([21.1262, 79.0640], {
      radius: 50,
      color: '#e11d48',
      fillColor: '#e11d48',
      fillOpacity: 0.45,
      weight: 2
    }).addTo(this.map);
    exit4Zone.bindTooltip("Exit 4 Funnel Gate: 94% Severe Hazard", { className: 'glass-panel text-xs text-rose-300 font-mono-code' });
    this.zonePolygons.push(exit4Zone);

    // Green Channel Exit 3 (Recommended Safe Diversion Route)
    const exit3Zone = L.circle([21.1258, 79.0652], {
      radius: 40,
      color: '#10b981',
      fillColor: '#10b981',
      fillOpacity: 0.25,
      weight: 1.5
    }).addTo(this.map);
    exit3Zone.bindTooltip("Exit 3 Green Corridor: 32% Clear Flow (Reroute Active)", { className: 'glass-panel text-xs text-emerald-300 font-mono-code' });
    this.zonePolygons.push(exit3Zone);
  }

  // Draw Dynamic Rerouting Green Vector Lines
  drawCrowdDiversionFlow() {
    // Green arrow polyline from near Exit 4 to Exit 3
    const diversionPath = [
      [21.1268, 79.0645],
      [21.1260, 79.0648],
      [21.1258, 79.0652]
    ];

    const polyline = L.polyline(diversionPath, {
      color: '#10b981',
      weight: 4,
      dashArray: '8, 8',
      className: 'animate-pulse'
    }).addTo(this.map);

    this.routePolylines.push(polyline);
  }

  highlightChildSighting(coords = [21.1255, 79.0669], childName = "Aaradhya Meshram") {
    // Zoom and pan to Gate 3
    this.map.flyTo(coords, 18, { animate: true, duration: 1.5 });

    const sightingIcon = L.divIcon({
      className: 'custom-tactical-pin',
      html: `
        <div class="relative flex items-center justify-center">
          <div class="w-12 h-12 rounded-full bg-pink-600/90 border-2 border-white flex items-center justify-center text-xl shadow-2xl animate-pulse-glow">
            👧
          </div>
          <div class="absolute -top-6 bg-pink-950 border border-pink-400 text-pink-200 text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap shadow">
            TARGET LOCATED: 94.2% AI MATCH
          </div>
        </div>
      `,
      iconSize: [48, 48],
      iconAnchor: [24, 24]
    });

    const sightingMarker = L.marker(coords, { icon: sightingIcon, zIndexOffset: 1000 }).addTo(this.map);
    sightingMarker.bindPopup(`
      <div class="p-2.5 space-y-1.5">
        <div class="font-extrabold text-sm text-pink-400 flex items-center gap-1.5">👧 AI Biometric Positive Match</div>
        <div class="text-xs text-white font-semibold">${childName} (Age 6, Chandrapur)</div>
        <div class="text-xs text-slate-300">Camera: <span class="font-mono-code text-cyan-300">CAM-09 (Gate 3 South)</span></div>
        <div class="text-xs text-emerald-300 font-semibold">Nearest Volunteer Dispatched: NSS Unit 7</div>
        <div class="mt-2 text-[10px] bg-slate-900 p-1.5 rounded border border-pink-500/40 text-slate-300">
          Identified by: Pink floral frock, yellow hairclip, facial feature vector similarity.
        </div>
      </div>
    `).openPopup();

    this.markers['child_sighting'] = sightingMarker;
  }
}

window.tacticalMap = new TacticalMapEngine();
