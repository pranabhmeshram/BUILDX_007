﻿/**
 * RAKSHA-SETU 360 - Tactical Audio Synthesis & Zoned PA Announcement Engine
 */

class AudioEngine {
  constructor() {
    this.audioCtx = null;
    this.isMuted = false;
  }

  initContext() {
    if (!this.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContext();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  // Station/PA System Double Chime (Bing-Bong)
  playPAChime() {
    if (this.isMuted) return;
    this.initContext();
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // First Tone (High Note)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.3, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.6);

    // Second Tone (Harmonic Fall)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(440, now + 0.25); // A4
    gain2.gain.setValueAtTime(0.35, now + 0.25);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.9);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.25);
    osc2.stop(now + 0.9);
  }

  // High Urgency Emergency Alert Pulse
  playEmergencyAlarm() {
    if (this.isMuted) return;
    this.initContext();
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    for (let i = 0; i < 3; i++) {
      const startTime = now + (i * 0.25);
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, startTime);
      osc.frequency.exponentialRampToValueAtTime(440, startTime + 0.18);

      gain.gain.setValueAtTime(0.2, startTime);
      gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.2);
    }
  }

  // AI Match Confirmation Sound
  playMatchSuccess() {
    if (this.isMuted) return;
    this.initContext();
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    const notes = [523.25, 659.25, 783.99, 1046.50]; // C Major Arpeggio
    notes.forEach((freq, idx) => {
      const startTime = now + (idx * 0.08);
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.25, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.4);
    });
  }

  // Zoned PA Broadcast using Web Speech API
  broadcastAnnouncement(text, lang = 'mr-IN', zoneName = 'All Zones') {
    this.playPAChime();

    if ('speechSynthesis' in window) {
      setTimeout(() => {
        window.speechSynthesis.cancel(); // Clear any ongoing speech
        const utterance = new SpeechSynthesisUtterance(text);
        
        // Match language locale
        if (lang === 'mr' || lang === 'mr-IN') {
          utterance.lang = 'mr-IN';
        } else if (lang === 'hi' || lang === 'hi-IN') {
          utterance.lang = 'hi-IN';
        } else {
          utterance.lang = 'en-IN';
        }

        utterance.rate = 0.92; // Clear, calm announcement pace
        utterance.pitch = 1.05;
        utterance.volume = 1.0;

        // Try to pick suitable voice if available
        const voices = window.speechSynthesis.getVoices();
        const indianVoice = voices.find(v => v.lang.includes('IN') || v.lang.includes(lang));
        if (indianVoice) {
          utterance.voice = indianVoice;
        }

        window.speechSynthesis.speak(utterance);
      }, 700);
    }

    console.log(`[PA LOUDSPEAKER BROADCAST] (${zoneName}) [${lang}]: "${text}"`);
  }

  stopAllSpeech() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}

window.soundEngine = new AudioEngine();
