﻿/**
 * RAKSHA-SETU 360 - Push-To-Talk (PTT) Digital Radio Dispatcher
 */

class PTTRadioModule {
  constructor() {
    this.currentChannel = "CH-03";
    this.isTransmitting = false;
    this.audioCtx = null;
    this.radioLogs = [
      { time: "5:40:12 PM", channel: "CH-03", sender: "Control Room (ICCC)", message: "Docket #0042 logged for lost child Aaradhya Meshram, Chandrapur. Pink frock.", type: "system" },
      { time: "5:43:00 PM", channel: "CH-02", sender: "PSI Patil (Exit 4)", message: "Exit 4 funnel gate reaching critical density. Requesting volunteer cordon.", type: "field" },
      { time: "5:48:15 PM", channel: "CH-03", sender: "Edge AI Cam CAM-09", message: "Positive AI match 94.2% detected at Gate 3 South perimeter.", type: "alert" },
      { time: "5:50:40 PM", channel: "CH-03", sender: "NSS Unit 7 (Rohan)", message: "Child sighted and accompanied safely to Gate 3 child sanctuary booth.", type: "field" },
      { time: "5:52:10 PM", channel: "CH-01", sender: "Medical Post A", message: "Mobile ICU unit standing by at Gate 3. All clear.", type: "medical" }
    ];
  }

  initAudio() {
    if (!this.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContext();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  // Squelch Noise & Roger Beep Audio Synthesizer
  playRadioBurst() {
    if (window.soundEngine.isMuted) return;
    this.initAudio();
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Noise buffer for static squelch
    const bufferSize = ctx.sampleRate * 0.08;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.15, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    noise.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noise.start(now);

    // High Roger Beep Tone (1200Hz)
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, now + 0.09);
    gain.gain.setValueAtTime(0.2, now + 0.09);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + 0.09);
    osc.stop(now + 0.22);
  }

  selectChannel(channelId) {
    this.currentChannel = channelId;
    this.playRadioBurst();
    return APP_DATA.radioChannels.find(c => c.id === channelId);
  }

  startTransmit() {
    this.isTransmitting = true;
    this.playRadioBurst();
  }

  stopTransmit(messageText) {
    this.isTransmitting = false;
    this.playRadioBurst();

    if (messageText && messageText.trim().length > 0) {
      const newLog = {
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        channel: this.currentChannel,
        sender: "Field Operator (You)",
        message: messageText,
        type: "user"
      };
      this.radioLogs.unshift(newLog);
      return newLog;
    }
    return null;
  }
}

window.pttRadio = new PTTRadioModule();
