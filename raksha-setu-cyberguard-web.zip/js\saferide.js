﻿/**
 * RAKSHA-SETU 360 - SafeRide GPS Route Guardian & Stealth Panic System
 */

class SafeRideModule {
  constructor() {
    this.isActive = false;
    this.currentLocation = "Sitabuldi Metro Station";
    this.destination = "Dharampeth West";
    this.vehicleNo = "MH-31-EQ-4412";
    this.deviationDetected = false;
    this.countdownTimer = null;
    this.countdownSeconds = 15;
    this.phoneMap = null;
    this.carMarker = null;
    this.routeCorridor = null;
  }

  initPhoneMap(containerId = 'saferide-phone-map') {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (this.phoneMap) {
      this.phoneMap.remove();
    }

    const startCoords = [21.1466, 79.0882]; // Sitabuldi

    this.phoneMap = L.map(containerId, {
      center: startCoords,
      zoom: 14,
      zoomControl: false,
      attributionControl: false
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19
    }).addTo(this.phoneMap);

    // Draw intended route corridor (Sitabuldi -> Dharampeth)
    const routeCoords = [
      [21.1466, 79.0882], // Sitabuldi
      [21.1480, 79.0750], // Law College Square
      [21.1450, 79.0620], // Dharampeth
    ];

    L.polyline(routeCoords, {
      color: '#06b6d4',
      weight: 4,
      dashArray: '4, 4'
    }).addTo(this.phoneMap);

    // Draggable Car Marker
    const carIcon = L.divIcon({
      className: 'custom-tactical-pin',
      html: `<div class="w-8 h-8 rounded-full bg-cyan-600 border-2 border-white flex items-center justify-center text-sm shadow-xl animate-pulse">🚕</div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    this.carMarker = L.marker(startCoords, { icon: carIcon, draggable: true }).addTo(this.phoneMap);

    this.carMarker.on('dragend', (e) => {
      const pos = e.target.getLatLng();
      // If dragged north towards Seminary Hills bypass, trigger deviation
      if (pos.lat > 21.1550 || pos.lng < 79.0550) {
        this.simulateRouteDeviation();
      }
    });
  }

  startRide(vehicleNo, destination) {
    this.isActive = true;
    this.vehicleNo = vehicleNo || "MH-31-EQ-4412";
    this.destination = destination || "Dharampeth West";
    this.deviationDetected = false;
    return {
      status: "ACTIVE",
      startTime: new Date().toLocaleTimeString(),
      corridorConfidence: "99.8%",
      contactsNotified: 3
    };
  }

  simulateRouteDeviation(onAlertCallback) {
    this.deviationDetected = true;
    this.countdownSeconds = 15;
    
    window.soundEngine.playEmergencyAlarm();

    if (this.countdownTimer) clearInterval(this.countdownTimer);

    // Pan phone map off-route
    if (this.phoneMap && this.carMarker) {
      const offRouteCoords = [21.1610, 79.0580]; // Seminary Hills forest bypass
      this.carMarker.setLatLng(offRouteCoords);
      this.phoneMap.panTo(offRouteCoords);
    }

    this.countdownTimer = setInterval(() => {
      this.countdownSeconds--;
      if (onAlertCallback) onAlertCallback(this.countdownSeconds);

      const countElem = document.getElementById('deviation-countdown-text');
      if (countElem) countElem.innerText = `${this.countdownSeconds}s`;

      if (this.countdownSeconds <= 0) {
        clearInterval(this.countdownTimer);
        this.triggerEmergencySOS("AUTO_DEVIATION_TIMEOUT");
      }
    }, 1000);
  }

  dismissAlert() {
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer);
      this.countdownTimer = null;
    }
    this.deviationDetected = false;
    window.app.showToast("✅ Route deviation alert dismissed by commuter", "info");
  }

  triggerEmergencySOS(reason = "MANUAL_PANIC_BUTTON") {
    this.dismissAlert();
    window.soundEngine.playEmergencyAlarm();

    const sosIncident = {
      id: "SOS-" + Math.floor(1000 + Math.random() * 9000),
      time: new Date().toLocaleTimeString(),
      type: "HIGH_PRIORITY_TRANSIT_SOS",
      victim: "Pooja Sharma (Commuter)",
      location: "Near Seminary Hills North Bypass (Off Route 480m)",
      coords: [21.1610, 79.0580],
      vehicle: this.vehicleNo,
      reason: reason,
      pcrDispatched: "PCR Van 14 (Nagpur Police West Zone)"
    };

    window.app.showToast(`🚨 HIGH PRIORITY SOS DISPATCHED: PCR Van 14 intercepting vehicle ${this.vehicleNo}`, "danger");
    return sosIncident;
  }

  triggerFakeCall() {
    this.fakeCallActive = true;
    window.soundEngine.playPAChime();
    const modal = document.getElementById('fake-call-modal');
    if (modal) modal.classList.remove('hidden');
    return {
      callerName: "Papa (ACP Crime Branch)",
      callerNumber: "+91 98220 99100"
    };
  }
}

window.safeRideModule = new SafeRideModule();
